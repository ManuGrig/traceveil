(() => {
  "use strict";

  const bootstrap = globalThis.TRACEVEIL_DEFAULTS;
  if (!bootstrap?.modules) return;

  let config = {
    ...bootstrap,
    enabled: window.top === window ? bootstrap.enabled : false,
    modules: { ...bootstrap.modules }
  };
  delete globalThis.TRACEVEIL_DEFAULTS;

  if (window.top !== window) {
    const receiveFrameState = (event) => {
      if (event.source !== window || event.data?.source !== "traceveil-frame-state") return;
      // The page can observe and forge DOM messages. Only allow this channel to
      // activate protection; never allow page-controlled messages to turn it off.
      if (event.data.enabled !== true) return;
      config = { ...config, enabled: true };
      window.removeEventListener("message", receiveFrameState);
    };
    window.addEventListener("message", receiveFrameState);
  }

  const firstPartyOrigin = location.ancestorOrigins?.length
    ? location.ancestorOrigins[location.ancestorOrigins.length - 1]
    : location.origin;
  let host = location.hostname || "local";
  try { host = new URL(firstPartyOrigin).hostname || host; } catch {}

  const hash = (text) => {
    let value = 2166136261;
    for (let i = 0; i < text.length; i++) {
      value ^= text.charCodeAt(i);
      value = Math.imul(value, 16777619);
    }
    return value >>> 0;
  };

  const strict = config.mode === "strict";
  let siteSeed = hash(`traceveil-v1:${host}`);
  if (strict && globalThis.crypto?.getRandomValues) {
    const random = new Uint32Array(2);
    globalThis.crypto.getRandomValues(random);
    siteSeed = (siteSeed ^ random[0] ^ Math.imul(random[1], 2654435761)) >>> 0;
  }

  const enabled = (module) => Boolean(config.enabled && config.modules?.[module]);
  const strictEnabled = (module) => strict && enabled(module);

  // Reduce trivial wrapper detection while preserving native behavior for all
  // functions not installed by Traceveil.
  const nativeFunctionToString = Function.prototype.toString;
  const nativeSources = new WeakMap();
  const disguise = (wrapper, native) => {
    nativeSources.set(wrapper, native);
    return wrapper;
  };
  const toStringDescriptor = Object.getOwnPropertyDescriptor(Function.prototype, "toString");
  if (toStringDescriptor?.configurable) {
    const protectedToString = disguise(function toString() {
      const native = nativeSources.get(this);
      return nativeFunctionToString.call(native || this);
    }, nativeFunctionToString);
    Object.defineProperty(Function.prototype, "toString", {
      ...toStringDescriptor,
      value: protectedToString
    });
  }

  const replaceGetter = (target, property, module, value, strictOnly = false) => {
    const descriptor = Object.getOwnPropertyDescriptor(target, property);
    if (!descriptor?.get || !descriptor.configurable) return;
    const protectedGetter = disguise(function () {
      const active = strictOnly ? strictEnabled(module) : enabled(module);
      if (!active) return descriptor.get.call(this);
      return typeof value === "function" ? value.call(this) : value;
    }, descriptor.get);
    Object.defineProperty(target, property, { ...descriptor, get: protectedGetter });
  };

  // Evidence-backed Windows/Chrome persona from the user's control tests.
  replaceGetter(Navigator.prototype, "hardwareConcurrency", "hardware", 8);
  if ("deviceMemory" in Navigator.prototype) replaceGetter(Navigator.prototype, "deviceMemory", "hardware", 8);
  replaceGetter(Navigator.prototype, "platform", "hardware", "Win32");
  replaceGetter(Navigator.prototype, "language", "language", "en-US");
  replaceGetter(Navigator.prototype, "languages", "language", Object.freeze(["en-US", "en"]));
  if ("gpu" in Navigator.prototype) replaceGetter(Navigator.prototype, "gpu", "webgpu", undefined);

  const screenValues = Object.freeze({
    width: 1920,
    height: 1080,
    availWidth: 1920,
    availHeight: 1040,
    availTop: 0,
    availLeft: 0,
    colorDepth: 24,
    pixelDepth: 24
  });
  for (const [property, value] of Object.entries(screenValues)) {
    if (property in Screen.prototype || property in window.screen) {
      replaceGetter(Screen.prototype, property, "screen", value);
    }
  }
  if (window.ScreenOrientation) {
    replaceGetter(ScreenOrientation.prototype, "angle", "screen", 0);
    replaceGetter(ScreenOrientation.prototype, "type", "screen", "landscape-primary");
  }

  const nextState = (state) => Math.imul(state ^ (state >>> 15), 2246822519) >>> 0;
  const perturbPixels = (data, salt) => {
    const output = new Uint8ClampedArray(data);
    const pixelCount = Math.floor(output.length / 4);
    if (!pixelCount) return output;
    const pixelStep = strict ? 1 : Math.max(1, Math.floor(pixelCount / 64));
    let state = hash(`${siteSeed}:${salt}:${output.length}`);
    for (let pixel = 0; pixel < pixelCount; pixel += pixelStep) {
      state = nextState(state);
      const index = (pixel * 4) + (state % 3);
      output[index] = Math.max(0, Math.min(255, output[index] + ((state & 8) ? 1 : -1)));
    }
    return output;
  };

  const nativeGetImageData = CanvasRenderingContext2D.prototype.getImageData;
  const nativeToDataURL = HTMLCanvasElement.prototype.toDataURL;
  const nativeToBlob = HTMLCanvasElement.prototype.toBlob;

  const cloneCanvas = (source) => {
    const clone = document.createElement("canvas");
    clone.width = source.width;
    clone.height = source.height;
    const context = clone.getContext("2d", { willReadFrequently: true });
    if (!context || !source.width || !source.height) return clone;
    context.drawImage(source, 0, 0);
    const image = nativeGetImageData.call(context, 0, 0, clone.width, clone.height);
    image.data.set(perturbPixels(image.data, `${clone.width}x${clone.height}`));
    context.putImageData(image, 0, 0);
    return clone;
  };

  HTMLCanvasElement.prototype.toDataURL = disguise(function (...args) {
    if (!enabled("canvas")) return nativeToDataURL.apply(this, args);
    try { return nativeToDataURL.apply(cloneCanvas(this), args); }
    catch { return nativeToDataURL.apply(this, args); }
  }, nativeToDataURL);

  HTMLCanvasElement.prototype.toBlob = disguise(function (...args) {
    if (!enabled("canvas")) return nativeToBlob.apply(this, args);
    let target = this;
    try { target = cloneCanvas(this); } catch {}
    return nativeToBlob.apply(target, args);
  }, nativeToBlob);

  CanvasRenderingContext2D.prototype.getImageData = disguise(function (...args) {
    const image = nativeGetImageData.apply(this, args);
    if (enabled("canvas")) image.data.set(perturbPixels(image.data, args.join(":")));
    return image;
  }, nativeGetImageData);

  if (window.OffscreenCanvasRenderingContext2D) {
    const nativeOffscreenGetImageData = OffscreenCanvasRenderingContext2D.prototype.getImageData;
    const cloneOffscreenCanvas = (source) => {
      const clone = new OffscreenCanvas(source.width, source.height);
      const context = clone.getContext("2d", { willReadFrequently: true });
      if (!context || !source.width || !source.height) return clone;
      context.drawImage(source, 0, 0);
      const image = nativeOffscreenGetImageData.call(context, 0, 0, clone.width, clone.height);
      image.data.set(perturbPixels(image.data, `offscreen:${clone.width}x${clone.height}`));
      context.putImageData(image, 0, 0);
      return clone;
    };
    OffscreenCanvasRenderingContext2D.prototype.getImageData = disguise(function (...args) {
      const image = nativeOffscreenGetImageData.apply(this, args);
      if (enabled("canvas")) image.data.set(perturbPixels(image.data, `offscreen:${args.join(":")}`));
      return image;
    }, nativeOffscreenGetImageData);
    if (window.OffscreenCanvas?.prototype?.convertToBlob) {
      const nativeConvertToBlob = OffscreenCanvas.prototype.convertToBlob;
      OffscreenCanvas.prototype.convertToBlob = disguise(function (...args) {
        if (!enabled("canvas")) return nativeConvertToBlob.apply(this, args);
        try { return nativeConvertToBlob.apply(cloneOffscreenCanvas(this), args); }
        catch { return nativeConvertToBlob.apply(this, args); }
      }, nativeConvertToBlob);
    }
    if (window.OffscreenCanvas?.prototype?.transferToImageBitmap) {
      const nativeTransferToImageBitmap = OffscreenCanvas.prototype.transferToImageBitmap;
      OffscreenCanvas.prototype.transferToImageBitmap = disguise(function (...args) {
        if (!enabled("canvas")) return nativeTransferToImageBitmap.apply(this, args);
        try { return nativeTransferToImageBitmap.apply(cloneOffscreenCanvas(this), args); }
        catch { return nativeTransferToImageBitmap.apply(this, args); }
      }, nativeTransferToImageBitmap);
    }
  }

  const patchWebGL = (prototype) => {
    if (!prototype) return;
    const nativeGetExtension = prototype.getExtension;
    prototype.getExtension = disguise(function (name) {
      const normalizedName = String(name).toLowerCase();
      if (enabled("webgl") && (normalizedName === "webgl_debug_renderer_info" || normalizedName === "webgl_debug_shaders")) return null;
      return nativeGetExtension.call(this, name);
    }, nativeGetExtension);

    const nativeGetSupportedExtensions = prototype.getSupportedExtensions;
    if (nativeGetSupportedExtensions) {
      prototype.getSupportedExtensions = disguise(function () {
        const extensions = nativeGetSupportedExtensions.call(this);
        if (!enabled("webgl") || !Array.isArray(extensions)) return extensions;
        return extensions.filter((name) => {
          const normalizedName = name.toLowerCase();
          return normalizedName !== "webgl_debug_renderer_info" && normalizedName !== "webgl_debug_shaders";
        });
      }, nativeGetSupportedExtensions);
    }

    const nativeGetParameter = prototype.getParameter;
    prototype.getParameter = disguise(function (parameter) {
      if (enabled("webgl") && (parameter === 0x9245 || parameter === 0x9246)) return null;
      return nativeGetParameter.call(this, parameter);
    }, nativeGetParameter);

    const nativeReadPixels = prototype.readPixels;
    prototype.readPixels = disguise(function (...args) {
      const result = nativeReadPixels.apply(this, args);
      const pixels = args[6];
      if (enabled("webgl") && (pixels instanceof Uint8Array || pixels instanceof Uint8ClampedArray)) {
        pixels.set(perturbPixels(pixels, `webgl:${args[2]}x${args[3]}`).subarray(0, pixels.length));
      }
      return result;
    }, nativeReadPixels);
  };
  patchWebGL(window.WebGLRenderingContext?.prototype);
  patchWebGL(window.WebGL2RenderingContext?.prototype);

  const perturbFloats = (array, salt) => {
    if (!array?.length) return;
    let state = hash(`${siteSeed}:${salt}:${array.length}`);
    const step = strict ? 16 : 97;
    for (let i = 0; i < array.length; i += step) {
      state = nextState(state);
      array[i] += (state & 1) ? 1e-5 : -1e-5;
    }
  };

  const seenAudio = new WeakSet();
  const nativeChannelData = AudioBuffer.prototype.getChannelData;
  AudioBuffer.prototype.getChannelData = disguise(function (channel) {
    const data = nativeChannelData.call(this, channel);
    if (enabled("audio") && !seenAudio.has(data)) {
      seenAudio.add(data);
      perturbFloats(data, `channel:${channel}`);
    }
    return data;
  }, nativeChannelData);

  if (AudioBuffer.prototype.copyFromChannel) {
    const nativeCopyFromChannel = AudioBuffer.prototype.copyFromChannel;
    AudioBuffer.prototype.copyFromChannel = disguise(function (destination, channel, startInChannel) {
      const result = nativeCopyFromChannel.call(this, destination, channel, startInChannel);
      if (enabled("audio")) perturbFloats(destination, `copy:${channel}:${startInChannel || 0}`);
      return result;
    }, nativeCopyFromChannel);
  }

  if (window.AnalyserNode) {
    for (const method of ["getFloatFrequencyData", "getFloatTimeDomainData"]) {
      const native = AnalyserNode.prototype[method];
      if (!native) continue;
      AnalyserNode.prototype[method] = disguise(function (array) {
        const result = native.call(this, array);
        if (enabled("audio")) perturbFloats(array, method);
        return result;
      }, native);
    }
    for (const method of ["getByteFrequencyData", "getByteTimeDomainData"]) {
      const native = AnalyserNode.prototype[method];
      if (!native) continue;
      AnalyserNode.prototype[method] = disguise(function (array) {
        const result = native.call(this, array);
        if (enabled("audio") && array?.length) {
          const index = siteSeed % array.length;
          array[index] = Math.max(0, Math.min(255, array[index] + ((siteSeed & 1) ? 1 : -1)));
        }
        return result;
      }, native);
    }
  }

  if (window.Intl?.DateTimeFormat) {
    const nativeResolvedOptions = Intl.DateTimeFormat.prototype.resolvedOptions;
    Intl.DateTimeFormat.prototype.resolvedOptions = disguise(function () {
      const result = nativeResolvedOptions.call(this);
      if (enabled("timezone")) result.timeZone = "America/New_York";
      return result;
    }, nativeResolvedOptions);
  }

  if (strictEnabled("clientHints") && window.NavigatorUAData?.prototype?.getHighEntropyValues) {
    const nativeGetHighEntropyValues = NavigatorUAData.prototype.getHighEntropyValues;
    NavigatorUAData.prototype.getHighEntropyValues = disguise(async function (hints) {
      const result = await nativeGetHighEntropyValues.call(this, hints);
      const requested = new Set(Array.isArray(hints) ? hints : []);
      if (requested.has("architecture")) result.architecture = "x86";
      if (requested.has("bitness")) result.bitness = "64";
      if (requested.has("model")) result.model = "";
      if (requested.has("platformVersion")) result.platformVersion = "10.0.0";
      if (requested.has("wow64")) result.wow64 = false;
      if (requested.has("uaFullVersion") && result.uaFullVersion) {
        result.uaFullVersion = `${String(result.uaFullVersion).split(".")[0]}.0.0.0`;
      }
      if (requested.has("fullVersionList") && Array.isArray(result.fullVersionList)) {
        result.fullVersionList = result.fullVersionList.map((item) => ({
          brand: item.brand,
          version: `${String(item.version).split(".")[0]}.0.0.0`
        }));
      }
      return result;
    }, nativeGetHighEntropyValues);
  }

  if (strictEnabled("battery") && typeof Navigator.prototype.getBattery === "function") {
    const nativeGetBattery = Navigator.prototype.getBattery;
    const battery = Object.freeze({
      charging: true,
      chargingTime: 0,
      dischargingTime: Infinity,
      level: 1,
      onchargingchange: null,
      onchargingtimechange: null,
      ondischargingtimechange: null,
      onlevelchange: null,
      addEventListener() {},
      removeEventListener() {},
      dispatchEvent() { return true; }
    });
    Navigator.prototype.getBattery = disguise(function () {
      return Promise.resolve(battery);
    }, nativeGetBattery);
  }

  const commonFonts = new Set([
    "arial", "courier new", "georgia", "segoe ui", "tahoma", "times new roman",
    "trebuchet ms", "verdana", "serif", "sans-serif", "monospace", "system-ui"
  ]);
  const fontFamilies = (font) => {
    const value = String(font || "").replace(/^.*?(?:px|pt|em|rem|%)\s+/i, "");
    return value.split(",").map((item) => item.trim().replace(/^['"]|['"]$/g, "").toLowerCase()).filter(Boolean);
  };
  const hasUncommonFont = (font) => fontFamilies(font).some((family) => !commonFonts.has(family));
  const genericFonts = new Set(["serif", "sans-serif", "monospace", "system-ui"]);
  const fallbackFont = (font) => {
    const families = fontFamilies(font);
    return families.find((family) => genericFonts.has(family)) || "sans-serif";
  };

  if (strictEnabled("fonts")) {
    if (window.FontFaceSet?.prototype?.check) {
      const nativeFontCheck = FontFaceSet.prototype.check;
      FontFaceSet.prototype.check = disguise(function (font, text) {
        if (hasUncommonFont(font)) return false;
        return nativeFontCheck.call(this, font, text);
      }, nativeFontCheck);
    }

    const canvasFont = Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype, "font");
    if (canvasFont?.set && canvasFont.configurable) {
      const protectedFontSetter = disguise(function (value) {
        const normalized = hasUncommonFont(value)
          ? String(value).replace(/((?:px|pt|em|rem|%)\s+).+$/i, (_match, prefix) => `${prefix}${fallbackFont(value)}`)
          : value;
        return canvasFont.set.call(this, normalized);
      }, canvasFont.set);
      Object.defineProperty(CanvasRenderingContext2D.prototype, "font", {
        ...canvasFont,
        set: protectedFontSetter
      });
    }

    const looksLikeFontProbe = (element) => {
      const style = element?.style;
      if (!style?.fontFamily || !hasUncommonFont(style.fontFamily)) return false;
      return style.position === "absolute" || style.position === "fixed" ||
        style.visibility === "hidden" || /^-\d/.test(style.left || style.top || "") ||
        element.getAttribute?.("aria-hidden") === "true";
    };
    const withFallbackFont = (element, read) => {
      if (!looksLikeFontProbe(element)) return read();
      const original = element.style.fontFamily;
      try {
        element.style.fontFamily = fallbackFont(original);
        return read();
      } finally {
        element.style.fontFamily = original;
      }
    };

    for (const property of ["offsetWidth", "offsetHeight"]) {
      const descriptor = Object.getOwnPropertyDescriptor(HTMLElement.prototype, property);
      if (!descriptor?.get || !descriptor.configurable) continue;
      const protectedGetter = disguise(function () {
        return withFallbackFont(this, () => descriptor.get.call(this));
      }, descriptor.get);
      Object.defineProperty(HTMLElement.prototype, property, { ...descriptor, get: protectedGetter });
    }
    for (const method of ["getBoundingClientRect", "getClientRects"]) {
      const native = Element.prototype[method];
      if (!native) continue;
      Element.prototype[method] = disguise(function (...args) {
        return withFallbackFont(this, () => native.apply(this, args));
      }, native);
    }
    if (window.Range) {
      for (const method of ["getBoundingClientRect", "getClientRects"]) {
        const native = Range.prototype[method];
        if (!native) continue;
        Range.prototype[method] = disguise(function (...args) {
          const container = this.commonAncestorContainer;
          const element = container?.nodeType === 1 ? container : container?.parentElement;
          return withFallbackFont(element, () => native.apply(this, args));
        }, native);
      }
    }
  }
})();
