# Third-Party Notices

This local build does not bundle or fetch third-party tracker datasets or third-party JavaScript libraries.

The tracker-domain seed in `rules/tracker-domains.json` is distributed as part of this project under 0BSD.

The Traceveil logo and derived icon files are project artwork. Before redistributing them under 0BSD, ensure that you hold the necessary rights to do so.
