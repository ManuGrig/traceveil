importScripts("defaults.js");

const DEFAULTS = TRACEVEIL_DEFAULTS;
const MAIN_SCRIPT_ID = "traceveil-main";
const LEGACY_MAIN_SCRIPT_IDS = Object.freeze(["identity-firewall-main"]);
const TRACKER_RULE_ID_START = 1000;
const TRACKER_RULE_CHUNK_SIZE = 500;
// Kept at 60 so upgrades from v1.1.0 remove every previously generated tracker rule.
const TRACKER_RULE_CHUNK_LIMIT = 60;
const LEGACY_TRACKER_CACHE_KEYS = Object.freeze(["trackerIntelligence", "trackerListStatus"]);
const NETWORK_RESOURCE_TYPES = Object.freeze([
  "main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object",
  "xmlhttprequest", "ping", "csp_report", "media", "websocket", "webtransport", "other"
]);
const MODULE_PROFILE_SCRIPTS = Object.freeze({
  canvas: "profile-disable-canvas.js",
  webgl: "profile-disable-webgl.js",
  webgpu: "profile-disable-webgpu.js",
  audio: "profile-disable-audio.js",
  hardware: "profile-disable-hardware.js",
  screen: "profile-disable-screen.js",
  language: "profile-disable-language.js",
  timezone: "profile-disable-timezone.js",
  clientHints: "profile-disable-client-hints.js",
  battery: "profile-disable-battery.js"
});

const TRACKING_PARAMETERS = Object.freeze([
  "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
  "utm_id", "gclid", "dclid", "fbclid", "msclkid", "mc_cid", "mc_eid",
  "_hsenc", "_hsmi", "vero_conv", "vero_id", "ref_src", "ref_url"
]);
const TRACKING_RULE_ID_START = 100;
const TRACKING_RULE_IDS = Object.freeze(Array.from(
  { length: TRACKING_PARAMETERS.length * 2 },
  (_, index) => TRACKING_RULE_ID_START + index
));
const TRACKER_RULE_IDS = Object.freeze(Array.from(
  { length: TRACKER_RULE_CHUNK_LIMIT },
  (_, index) => TRACKER_RULE_ID_START + index
));
// Includes legacy ids 5 and 6 from earlier prototypes so updateDynamicRules cleans them.
const DYNAMIC_RULE_IDS = Object.freeze([1, 2, 3, 4, 5, 6, ...TRACKING_RULE_IDS, ...TRACKER_RULE_IDS]);

const readConfig = async () => {
  const stored = await chrome.storage.local.get(DEFAULTS);
  return {
    ...DEFAULTS,
    ...stored,
    mode: stored.mode === "aggressive" ? "strict" : (stored.mode || DEFAULTS.mode),
    disabledSites: Array.isArray(stored.disabledSites) ? stored.disabledSites : [],
    modules: { ...DEFAULTS.modules, ...(stored.modules || {}) }
  };
};

const normalizedSites = (sites) => sites
  .map((site) => String(site).trim().toLowerCase())
  .filter((site) => /^(?:[a-z0-9-]+\.)*[a-z0-9-]+$/i.test(site));

const isSiteDisabled = (host, sites) => {
  const normalizedHost = String(host || "").toLowerCase();
  return normalizedSites(sites).some((site) => normalizedHost === site || normalizedHost.endsWith(`.${site}`));
};

const sitePatterns = (sites) => normalizedSites(sites)
  .flatMap((site) => [`*://${site}/*`, `*://*.${site}/*`]);

const addDomainExclusions = (condition, sites, { request = false, initiator = false } = {}) => {
  const domains = normalizedSites(sites);
  if (domains.length && request) condition.excludedRequestDomains = domains;
  if (domains.length && initiator) condition.excludedInitiatorDomains = domains;
  return condition;
};

const normalizeTrackerDomains = (domains) => [...new Set((Array.isArray(domains) ? domains : [])
  .map((domain) => String(domain).trim().toLowerCase().replace(/^\.+|\.+$/g, ""))
  .filter((domain) => domain.length <= 253 && /^(?:[a-z0-9-]+\.)+[a-z0-9-]+$/.test(domain))
  .filter((domain) => !domain.split(".").some((label) => !label || label.length > 63 || label.startsWith("-") || label.endsWith("-"))))]
  .sort();

const loadTrackerSeed = async () => {
  const response = await fetch(chrome.runtime.getURL("rules/tracker-domains.json"));
  if (!response.ok) throw new Error(`Bundled tracker data returned HTTP ${response.status}`);
  const seed = await response.json();
  return {
    version: seed.version || 1,
    updated: seed.updated || null,
    source: seed.source || "Traceveil local tracker seed",
    balanced: normalizeTrackerDomains(seed.balanced),
    strict: normalizeTrackerDomains(seed.strict)
  };
};

const loadTrackerDomains = async (mode) => {
  const seed = await loadTrackerSeed();
  return normalizeTrackerDomains([
    ...seed.balanced,
    ...(mode === "strict" ? seed.strict : [])
  ]).slice(0, TRACKER_RULE_CHUNK_SIZE * TRACKER_RULE_CHUNK_LIMIT);
};

const trackerState = async (mode) => {
  const [seed, domains] = await Promise.all([
    loadTrackerSeed(),
    loadTrackerDomains(mode)
  ]);
  return {
    ok: true,
    source: seed.source,
    updatedAt: seed.updated,
    count: domains.length,
    activeCount: domains.length,
    localOnly: true
  };
};

const syncMainWorldScript = async () => {
  const config = await readConfig();
  await chrome.scripting.unregisterContentScripts({ ids: [MAIN_SCRIPT_ID, ...LEGACY_MAIN_SCRIPT_IDS] }).catch(() => {});
  if (!config.enabled) return;

  const registration = {
    id: MAIN_SCRIPT_ID,
    matches: ["http://*/*", "https://*/*"],
    js: [
      "defaults.js",
      ...(config.mode === "strict" ? ["profile-strict.js"] : []),
      ...Object.entries(MODULE_PROFILE_SCRIPTS)
        .filter(([module]) => !config.modules[module])
        .map(([, script]) => script),
      ...(config.modules.fonts ? ["profile-enable-fonts.js"] : []),
      "main-world.js"
    ],
    runAt: "document_start",
    world: "MAIN",
    allFrames: true,
    matchOriginAsFallback: true,
    persistAcrossSessions: true
  };
  const excludeMatches = sitePatterns(config.disabledSites);
  if (excludeMatches.length) registration.excludeMatches = excludeMatches;
  await chrome.scripting.registerContentScripts([registration]);
};

const syncNetworkRules = async () => {
  const config = await readConfig();
  const addRules = [];
  if (!config.enabled) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: DYNAMIC_RULE_IDS });
    return;
  }

  if (config.modules.language) {
    addRules.push({
      id: 1,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [{ header: "accept-language", operation: "set", value: "en-US,en;q=0.9" }]
      },
      condition: addDomainExclusions({
        urlFilter: "http",
        resourceTypes: [...NETWORK_RESOURCE_TYPES]
      }, config.disabledSites, { request: true, initiator: true })
    });
  }

  if (config.mode === "strict" && config.modules.clientHints) {
    addRules.push({
      id: 2,
      priority: 2,
      action: {
        type: "modifyHeaders",
        requestHeaders: [
          "sec-ch-ua-arch", "sec-ch-ua-bitness", "sec-ch-ua-full-version",
          "sec-ch-ua-full-version-list", "sec-ch-ua-model", "sec-ch-ua-platform-version",
          "sec-ch-ua-wow64"
        ].map((header) => ({ header, operation: "remove" }))
      },
      condition: addDomainExclusions({
        urlFilter: "http",
        resourceTypes: [...NETWORK_RESOURCE_TYPES]
      }, config.disabledSites, { request: true, initiator: true })
    });
    addRules.push({
      id: 3,
      priority: 2,
      action: {
        type: "modifyHeaders",
        responseHeaders: [
          { header: "accept-ch", operation: "remove" },
          { header: "critical-ch", operation: "remove" }
        ]
      },
      condition: addDomainExclusions({
        urlFilter: "http",
        resourceTypes: ["main_frame", "sub_frame"]
      }, config.disabledSites, { request: true, initiator: true })
    });
  }

  if (config.modules.trackerBlocking) {
    addRules.push({
      id: 4,
      priority: 3,
      action: { type: "block" },
      condition: addDomainExclusions({
        urlFilter: "http",
        domainType: "thirdParty",
        resourceTypes: ["ping"]
      }, config.disabledSites, { initiator: true })
    });
    const trackerDomains = await loadTrackerDomains(config.mode);
    for (let offset = 0; offset < trackerDomains.length; offset += TRACKER_RULE_CHUNK_SIZE) {
      const chunkIndex = offset / TRACKER_RULE_CHUNK_SIZE;
      addRules.push({
        id: TRACKER_RULE_ID_START + chunkIndex,
        priority: 2,
        action: { type: "block" },
        condition: addDomainExclusions({
          requestDomains: trackerDomains.slice(offset, offset + TRACKER_RULE_CHUNK_SIZE),
          domainType: "thirdParty",
          resourceTypes: ["sub_frame", "script", "image", "stylesheet", "font", "xmlhttprequest", "ping", "media", "websocket", "webtransport", "other"]
        }, config.disabledSites, { initiator: true })
      });
    }
  }

  if (config.modules.trackingParams) {
    TRACKING_PARAMETERS.forEach((parameter, parameterIndex) => {
      ["?", "&"].forEach((separator, separatorIndex) => {
        addRules.push({
          id: TRACKING_RULE_ID_START + (parameterIndex * 2) + separatorIndex,
          priority: 1,
          action: {
            type: "redirect",
            redirect: { transform: { queryTransform: { removeParams: [...TRACKING_PARAMETERS] } } }
          },
          condition: addDomainExclusions({
            urlFilter: `${separator}${parameter}=`,
            resourceTypes: ["main_frame"]
          }, config.disabledSites, { request: true })
        });
      });
    });
  }

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: DYNAMIC_RULE_IDS,
    addRules
  });
};

const applyChromeSetting = async (setting, active, value) => {
  if (!setting) return;
  const details = await setting.get({});
  if (active) {
    if (details.levelOfControl === "controllable_by_this_extension" || details.levelOfControl === "controlled_by_this_extension") {
      await setting.set({ value, scope: "regular" });
    }
  } else if (details.levelOfControl === "controlled_by_this_extension") {
    await setting.clear({ scope: "regular" });
  }
};

const syncPrivacySettings = async () => {
  const config = await readConfig();
  const privacy = chrome.privacy;
  if (!privacy) return;
  const strictMode = config.mode === "strict";
  const settings = [
    ["WebRTC routing", privacy.network?.webRTCIPHandlingPolicy, config.enabled && config.modules.webRTC, "disable_non_proxied_udp"],
    ["hyperlink auditing", privacy.websites?.hyperlinkAuditingEnabled, config.enabled && config.modules.trackerBlocking, false],
    ["ad measurement", privacy.websites?.adMeasurementEnabled, config.enabled && config.modules.privacySandbox, false],
    ["Protected Audience", privacy.websites?.fledgeEnabled, config.enabled && config.modules.privacySandbox, false],
    ["Topics", privacy.websites?.topicsEnabled, config.enabled && config.modules.privacySandbox, false],
    ["Related Website Sets", privacy.websites?.relatedWebsiteSetsEnabled, config.enabled && config.modules.privacySandbox, false],
    ["third-party cookies", privacy.websites?.thirdPartyCookiesAllowed, config.enabled && strictMode && config.modules.thirdPartyCookies, false],
    ["network prediction", privacy.network?.networkPredictionEnabled, config.enabled && strictMode && config.modules.networkPrediction, false]
  ];

  const results = await Promise.allSettled(
    settings.map(([, setting, active, value]) => applyChromeSetting(setting, active, value))
  );
  results.forEach((result, index) => {
    if (result.status === "rejected") {
      // Privacy API availability and policy control vary by Chrome build and
      // administrator policy. A rejected optional setting must not prevent the
      // fingerprint and network protections from installing.
      console.warn(`Traceveil could not apply ${settings[index][0]}:`, result.reason);
    }
  });
};

let syncQueue = Promise.resolve();
const scheduleSync = ({ main = true, network = true, privacy = true } = {}) => {
  syncQueue = syncQueue
    .catch(() => {})
    .then(() => Promise.all([
      ...(main ? [syncMainWorldScript()] : []),
      ...(network ? [syncNetworkRules()] : []),
      ...(privacy ? [syncPrivacySettings()] : [])
    ]));
  return syncQueue;
};

const initializeExtension = async (details) => {
  try {
    const current = await chrome.storage.local.get(Object.keys(DEFAULTS));
    const update = {
      modules: { ...DEFAULTS.modules, ...(current.modules || {}) }
    };
    for (const [key, value] of Object.entries(DEFAULTS)) {
      if (current[key] === undefined) update[key] = value;
    }
    if (current.mode === "aggressive") update.mode = "strict";
    if (details.reason === "update" && ["1.0.0", "1.0.1"].includes(details.previousVersion)) {
      update.modules.fonts = false;
    }
    await chrome.storage.local.set(update);
    // Remove cache/status keys from the online-list v1.1.0 build.
    await chrome.storage.local.remove(LEGACY_TRACKER_CACHE_KEYS).catch(() => {});
    await scheduleSync();
  } catch (error) {
    // Keep the worker healthy and avoid creating a permanent chrome://extensions
    // error entry for an install-time or policy-specific failure.
    console.warn("Traceveil install sync was incomplete:", error);
  }
};

chrome.runtime.onInstalled.addListener((details) => {
  void initializeExtension(details);
});

chrome.runtime.onStartup.addListener(() => {
  void scheduleSync().catch((error) => console.warn("Traceveil startup sync was incomplete:", error));
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local") return;
  if (changes.enabled || changes.disabledSites || changes.mode || changes.modules) {
    void scheduleSync().catch((error) => console.warn("Traceveil settings sync was incomplete:", error));
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "sync-config") {
    scheduleSync()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message.type === "standardize-window") {
    (async () => {
      await scheduleSync();
      await chrome.windows.update(message.windowId, { state: "normal" });
      await new Promise((resolve) => setTimeout(resolve, 150));
      await chrome.windows.update(message.windowId, { width: 1600, height: 900 });
      if (message.tabId !== undefined) await chrome.tabs.reload(message.tabId);
      sendResponse({ ok: true });
    })().catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message.type === "get-frame-state") {
    readConfig()
      .then((config) => sendResponse({
        enabled: config.enabled && !isSiteDisabled(message.host, config.disabledSites)
      }))
      .catch(() => sendResponse({ enabled: false }));
    return true;
  }

  if (message.type === "get-tracker-state") {
    readConfig()
      .then((config) => trackerState(config.mode))
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
});
