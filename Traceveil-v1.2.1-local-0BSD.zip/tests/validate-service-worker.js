const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const source = fs.readFileSync(path.join(root, "service-worker.js"), "utf8");
const defaultsSource = fs.readFileSync(path.join(root, "defaults.js"), "utf8");
const trackerSeed = JSON.parse(fs.readFileSync(path.join(root, "rules/tracker-domains.json"), "utf8"));

const listeners = {};
const registeredScripts = [];
const unregisteredScriptIds = [];
const dynamicUpdates = [];
const storage = {};

const makeEvent = (name) => ({
  addListener(callback) {
    listeners[name] = callback;
  }
});

const makeSetting = (initialValue = true) => {
  let value = initialValue;
  let controlled = false;
  return {
    async get() {
      return {
        value,
        levelOfControl: controlled ? "controlled_by_this_extension" : "controllable_by_this_extension"
      };
    },
    async set(details) {
      value = details.value;
      controlled = true;
    },
    async clear() {
      controlled = false;
    }
  };
};

const chrome = {
  runtime: {
    getURL: (file) => `chrome-extension://test/${file}`,
    onInstalled: makeEvent("installed"),
    onStartup: makeEvent("startup"),
    onMessage: makeEvent("message")
  },
  storage: {
    local: {
      async get(defaultsOrKeys) {
        if (Array.isArray(defaultsOrKeys)) {
          return Object.fromEntries(defaultsOrKeys.filter((key) => key in storage).map((key) => [key, storage[key]]));
        }
        if (defaultsOrKeys && typeof defaultsOrKeys === "object") return { ...defaultsOrKeys, ...storage };
        return { ...storage };
      },
      async set(values) { Object.assign(storage, values); },
      async remove(keys) { for (const key of [].concat(keys)) delete storage[key]; }
    },
    onChanged: makeEvent("storageChanged")
  },
  scripting: {
    async unregisterContentScripts({ ids }) { unregisteredScriptIds.push(...ids); },
    async registerContentScripts(scripts) { registeredScripts.push(...scripts); }
  },
  declarativeNetRequest: {
    async updateDynamicRules(update) { dynamicUpdates.push(update); }
  },
  privacy: {
    network: {
      webRTCIPHandlingPolicy: makeSetting("default"),
      networkPredictionEnabled: makeSetting(true)
    },
    websites: {
      hyperlinkAuditingEnabled: makeSetting(true),
      adMeasurementEnabled: makeSetting(true),
      fledgeEnabled: makeSetting(true),
      topicsEnabled: makeSetting(true),
      relatedWebsiteSetsEnabled: makeSetting(true),
      thirdPartyCookiesAllowed: makeSetting(true)
    }
  },
  windows: { async update() {} },
  tabs: { async reload() {} }
};

const context = vm.createContext({
  chrome,
  console,
  fetch: async (url) => {
    if (!String(url).endsWith("rules/tracker-domains.json")) throw new Error(`Unexpected fetch ${url}`);
    return { ok: true, status: 200, async json() { return trackerSeed; } };
  },
  importScripts: (...files) => {
    for (const file of files) vm.runInContext(fs.readFileSync(path.join(root, file), "utf8"), context, { filename: file });
  },
  setTimeout
});

vm.runInContext(source, context, { filename: "service-worker.js" });

(async () => {
  if (!listeners.installed) throw new Error("onInstalled listener missing");
  listeners.installed({ reason: "install" });
  await new Promise((resolve) => setTimeout(resolve, 20));

  const script = registeredScripts.at(-1);
  if (!script) throw new Error("Main-world script was not registered");
  if (script.id !== "traceveil-main") throw new Error(`Unexpected script id ${script.id}`);
  if (script.world !== "MAIN" || script.runAt !== "document_start" || !script.allFrames) {
    throw new Error("Main-world registration is incomplete");
  }
  if (!script.matchOriginAsFallback) throw new Error("Main-world registration lacks matchOriginAsFallback");
  if (!script.js.includes("main-world.js") || script.js[0] !== "defaults.js") throw new Error("Script load order is invalid");
  if (!unregisteredScriptIds.includes("identity-firewall-main")) throw new Error("Legacy dynamic script id is not cleaned up");

  const update = dynamicUpdates.at(-1);
  if (!update) throw new Error("Dynamic rules were not synchronized");
  const ids = update.addRules.map((rule) => rule.id);
  if (new Set(ids).size !== ids.length) throw new Error("Dynamic rule IDs are not unique");
  if (update.addRules.some((rule) => rule.condition.regexFilter)) throw new Error("Regex rules are not allowed in this build");

  const languageRule = update.addRules.find((rule) => rule.id === 1);
  if (!languageRule) throw new Error("Accept-Language rule missing");
  const languageHeader = languageRule.action.requestHeaders?.find((header) => header.header === "accept-language");
  if (languageHeader?.value !== "en-US,en;q=0.9") throw new Error("Accept-Language normalization mismatch");

  const trackerRule = update.addRules.find((rule) => rule.id >= 1000);
  if (!trackerRule) throw new Error("Tracker-domain rule missing");
  if (trackerRule.condition.requestDomains.length !== trackerSeed.balanced.length) {
    throw new Error("Balanced tracker-domain count mismatch");
  }
  if (trackerRule.condition.domainType !== "thirdParty") throw new Error("Tracker rule must be third-party only");

  const parameterRules = update.addRules.filter((rule) => rule.id >= 100 && rule.id < 1000);
  if (parameterRules.length !== 36) throw new Error(`Expected 36 parameter rules, found ${parameterRules.length}`);
  if (parameterRules.some((rule) => !rule.action.redirect?.transform?.queryTransform?.removeParams)) {
    throw new Error("Tracking-parameter rules must use queryTransform.removeParams");
  }

  console.log("Traceveil service-worker validation passed");
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
