if (window.top !== window) {
  const firstPartyOrigin = location.ancestorOrigins?.length
    ? location.ancestorOrigins[location.ancestorOrigins.length - 1]
    : location.origin;
  let host = location.hostname;
  try { host = new URL(firstPartyOrigin).hostname; } catch {}

  chrome.runtime.sendMessage({ type: "get-frame-state", host }, (state) => {
    if (chrome.runtime.lastError || typeof state?.enabled !== "boolean") return;
    window.postMessage({ source: "identity-firewall-frame-state", enabled: state.enabled }, "*");
  });
}
