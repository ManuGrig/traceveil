# Third-Party Notices

This local 0BSD build does not bundle or fetch third-party tracker datasets.

The tracker-domain seed in `rules/tracker-domains.json` is distributed as part of this project under 0BSD. Replace or remove the included icon artwork before publishing if you do not own the rights to release it under the same terms.
