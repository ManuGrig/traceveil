const MODULE_GROUPS = Object.freeze({
  fingerprintModules: [
    ["canvas", "Canvas output"],
    ["webgl", "WebGL output and GPU"],
    ["webgpu", "WebGPU adapter"],
    ["audio", "Audio output"],
    ["hardware", "CPU, memory and platform"],
    ["screen", "Screen geometry"],
    ["language", "Language"],
    ["timezone", "Timezone"],
    ["clientHints", "High-entropy Client Hints", true],
    ["fonts", "Experimental font probing", true],
    ["battery", "Battery state", true]
  ],
  networkModules: [
    ["webRTC", "WebRTC local-IP protection"],
    ["trackerBlocking", "Known third-party trackers"],
    ["trackingParams", "Tracking URL parameters"],
    ["privacySandbox", "Privacy Sandbox tracking APIs"],
    ["thirdPartyCookies", "Block third-party cookies", true],
    ["networkPrediction", "Disable network prediction", true]
  ]
});

(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let host = "";
  try { host = new URL(tab?.url).hostname; } catch {}
  document.querySelector("#host").textContent = host || "Chrome page";

  const stored = await chrome.storage.local.get(IDENTITY_FIREWALL_DEFAULTS);
  const config = {
    ...IDENTITY_FIREWALL_DEFAULTS,
    ...stored,
    mode: stored.mode === "aggressive" ? "strict" : (stored.mode || "balanced"),
    disabledSites: Array.isArray(stored.disabledSites) ? stored.disabledSites : [],
    modules: { ...IDENTITY_FIREWALL_DEFAULTS.modules, ...(stored.modules || {}) }
  };

  const enabledInput = document.querySelector("#enabled");
  const siteInput = document.querySelector("#siteEnabled");
  const modeInput = document.querySelector("#mode");
  const standardizeButton = document.querySelector("#standardizeWindow");
  const trackerStateLabel = document.querySelector("#trackerState");
  enabledInput.checked = Boolean(config.enabled);
  const siteIsDisabled = () => config.disabledSites.some((site) => {
    const normalizedSite = String(site).toLowerCase();
    return host === normalizedSite || host.endsWith(`.${normalizedSite}`);
  });
  siteInput.checked = host ? !siteIsDisabled() : false;
  siteInput.disabled = !host;
  modeInput.value = config.mode;

  const renderTrackerState = (state) => {
    const count = Number(state?.activeCount ?? state?.count ?? 0);
    const suffix = state?.updatedAt
      ? `; local seed ${new Date(state.updatedAt).toLocaleDateString()}`
      : "; local seed active";
    trackerStateLabel.textContent = `${count.toLocaleString()} tracker domains active${suffix}`;
  };

  const loadTrackerState = async () => {
    const state = await chrome.runtime.sendMessage({ type: "get-tracker-state" })
      .catch((error) => ({ ok: false, error: error.message }));
    renderTrackerState(state);
  };

  const renderStatus = () => {
    const active = Boolean(config.enabled && siteInput.checked);
    const status = document.querySelector(".status");
    status.classList.toggle("off", !active);
    document.querySelector("#status").textContent = active ? "Protection active" : "Protection off";
    document.querySelector("#summary").textContent = active
      ? `${config.mode === "strict" ? "strict" : "balanced"} protection on this site`
      : config.enabled
        ? "Page protection off; global privacy settings remain active"
        : "This site sees the original browser values";
    standardizeButton.hidden = config.mode !== "strict";
    document.querySelectorAll(".strict-only").forEach((row) => {
      row.classList.toggle("dormant", config.mode !== "strict");
    });
  };

  const syncAndReload = async () => {
    renderStatus();
    const response = await chrome.runtime.sendMessage({ type: "sync-config" }).catch((error) => ({
      ok: false,
      error: error.message
    }));
    if (response?.ok && tab?.id && /^https?:/.test(tab.url || "")) {
      await chrome.tabs.reload(tab.id);
    }
  };

  const standardizeWindow = async () => {
    standardizeButton.disabled = true;
    standardizeButton.textContent = "Standardizing...";
    const currentWindow = await chrome.windows.getCurrent();
    const response = await chrome.runtime.sendMessage({
      type: "standardize-window",
      windowId: currentWindow.id,
      tabId: tab?.id
    }).catch((error) => ({ ok: false, error: error.message }));
    if (!response?.ok) {
      standardizeButton.textContent = "Resize failed - try manually";
      standardizeButton.disabled = false;
    }
  };

  for (const [rootId, modules] of Object.entries(MODULE_GROUPS)) {
    const root = document.querySelector(`#${rootId}`);
    for (const [key, label, strictOnly = false] of modules) {
      const row = document.createElement("label");
      row.className = `row${strictOnly ? " strict-only" : ""}`;
      const text = document.createElement("span");
      text.textContent = label;
      const input = document.createElement("input");
      input.type = "checkbox";
      input.dataset.module = key;
      input.checked = Boolean(config.modules[key]);
      input.addEventListener("change", async () => {
        config.modules[key] = input.checked;
        await chrome.storage.local.set({ modules: config.modules });
        await syncAndReload();
      });
      row.append(text, input);
      root.append(row);
    }
  }

  enabledInput.addEventListener("change", async () => {
    config.enabled = enabledInput.checked;
    await chrome.storage.local.set({ enabled: config.enabled });
    await syncAndReload();
  });

  siteInput.addEventListener("change", async () => {
    const sites = new Set(config.disabledSites);
    if (siteInput.checked) {
      for (const site of sites) {
        const normalizedSite = String(site).toLowerCase();
        if (host === normalizedSite || host.endsWith(`.${normalizedSite}`)) sites.delete(site);
      }
    } else {
      sites.add(host);
    }
    config.disabledSites = [...sites];
    await chrome.storage.local.set({ disabledSites: config.disabledSites });
    await syncAndReload();
  });

  modeInput.addEventListener("change", async () => {
    config.mode = modeInput.value;
    await chrome.storage.local.set({ mode: config.mode });
    renderStatus();
    if (config.mode === "strict") await standardizeWindow();
    else await syncAndReload();
  });

  standardizeButton.addEventListener("click", standardizeWindow);
  renderStatus();
  await loadTrackerState();
})();
