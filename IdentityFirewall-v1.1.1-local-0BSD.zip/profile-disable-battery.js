if (!globalThis.IDENTITY_FIREWALL_DEFAULTS) throw new Error("Identity Firewall defaults unavailable");
globalThis.IDENTITY_FIREWALL_DEFAULTS = Object.freeze({
  ...globalThis.IDENTITY_FIREWALL_DEFAULTS,
  modules: Object.freeze({ ...globalThis.IDENTITY_FIREWALL_DEFAULTS.modules, battery: false })
});
