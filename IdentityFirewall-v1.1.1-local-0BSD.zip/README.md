# Identity Firewall v1.1.1 Local

A Chrome Manifest V3 extension prototype that reduces browser fingerprint linkability, limits high-entropy data exposure, and applies local tracking-resistance controls without telemetry or external tracker-list updates.

This build is designed for permissive GitHub publication under 0BSD. It removes the online tracker-intelligence component from v1.1.0 and uses only the small bundled local tracker seed included in this repository.

## License

Original source code and the bundled local tracker seed are released under the Zero-Clause BSD license. See `LICENSE`.

If you publish this repository, make sure the included icon artwork is also yours to release under the same terms. Replace the icons before publishing if that is not the case.

## Install locally

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select this folder.
5. Reload any already-open pages.

## Protection modes

### Balanced

Balanced mode uses the profile validated against the supplied protected/unprotected Cover Your Tracks tests:

- `en-US,en;q=0.9` language profile
- `America/New_York` timezone name
- 1920 x 1080 x 24 screen profile
- 8 CPU threads and 8 GB memory
- hidden WebGL debug renderer and WebGPU adapter
- stable first-party canvas, WebGL, and audio interference

Balanced mode prioritizes normal site behavior.

### Strict

Strict mode includes Balanced protection and additionally:

- generates a fresh private interference seed for each navigation
- applies denser canvas, WebGL, and audio interference
- protects OffscreenCanvas serialization and Range-based font probes
- reduces high-entropy User-Agent Client Hints in JavaScript and network requests
- suppresses server `Accept-CH` and `Critical-CH` negotiation
- normalizes battery state
- offers experimental font-enumeration resistance, disabled by default
- standardizes the real Chrome window to 1600 x 900 when Strict mode is selected
- blocks third-party cookies and disables network prediction through Chrome settings

Strict mode can affect font-sensitive editors, graphics tools, device-detection flows, and some authentication systems. Use the per-site switch when compatibility matters.

## Network privacy

- Sets Chrome's WebRTC policy to `disable_non_proxied_udp` while enabled.
- Disables hyperlink auditing and Chrome Privacy Sandbox ad-measurement, Protected Audience, Topics, and Related Website Sets APIs where Chrome exposes those controls.
- Blocks third-party ping requests.
- Blocks a small, bundled, local 0BSD tracker-domain seed.
- Removes common tracking parameters such as `utm_*`, `gclid`, `fbclid`, and `msclkid` from top-level navigation URLs.
- Excludes disabled sites from applicable request rules.

This local build deliberately avoids external tracker-list retrieval. Its domain blocker is therefore much smaller than a dedicated content blocker or a build that imports maintained third-party intelligence.

## Privacy architecture

- Main-world protection loads at `document_start` with its exact module state.
- Top-level pages do not receive configuration messages.
- Frames receive only one effective enabled/disabled boolean.
- The v0.x page-visible API diagnostics channel has been removed.
- Installed wrappers preserve native `Function.prototype.toString()` output for basic compatibility checks.
- Settings, matching, tracker-domain data, and processing remain local.
- The extension has no server component, no telemetry, and no scheduled network update task.

## Evidence from the supplied control test

Compared with the same browser without Identity Firewall, v0.9 made the tested values approximately:

- WebGL hash: 8,405 times more common
- Canvas: 776 times more common
- HTTP language profile: 831 times more common
- Screen profile: 331 times more common
- WebGL renderer: 61 times more common
- CPU profile: 33 times more common

v1.x retains those validated Balanced values and adds separate Strict protections instead of replacing them with untested renderer identities.

## Deliberate limits

A Chrome extension cannot control the browser's TLS, HTTP/2, HTTP/3, QUIC, IP, DNS, or complete native rendering fingerprint. It cannot guarantee anonymity or create a large uniform anonymity population. Main-world JavaScript patches remain detectable to sufficiently active scripts even when basic wrapper inspection is reduced.

The domain blocker deliberately avoids cosmetic filtering and broad URL-pattern rules, so it is still narrower than a dedicated content blocker. User-Agent spoofing is deliberately avoided because disagreement with Chrome's network behavior and Client Hints can increase uniqueness.

## Test procedure

1. Keep the unprotected Cover Your Tracks and AmIUnique reports as the baseline.
2. Test Balanced mode in a fresh tab.
3. Test Strict mode after the window is standardized.
4. Compare per-metric values, not only the overall uniqueness label.
5. Verify normal use on banking, video calls, maps, graphics tools, editors, and authentication pages.

Cover Your Tracks' overall bit score is capped by the size of its recent sample. A unique full combination can retain the same headline score even when individual high-entropy attributes become substantially more common.
