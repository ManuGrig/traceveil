const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const mustExist = (file) => {
  if (!fs.existsSync(path.join(root, file))) throw new Error(`Missing ${file}`);
};

const manifest = JSON.parse(read('manifest.json'));
if (manifest.version !== '1.1.1') throw new Error(`Unexpected manifest version ${manifest.version}`);
if (manifest.permissions.includes('alarms')) throw new Error('alarms permission must not be present');
for (const size of ['16', '32', '48', '128']) mustExist(manifest.icons[size]);
for (const script of manifest.content_scripts.flatMap((entry) => entry.js)) mustExist(script);
mustExist(manifest.background.service_worker);

const forbidden = [/staticcdn/i, /trackerblocking\/v6/i, /tds\.json/i, /TRACKER_LIST_URL/, /refresh-tracker-list/i, /chrome\.alarms/];
for (const file of fs.readdirSync(root, { recursive: true })) {
  const full = path.join(root, file);
  if (fs.statSync(full).isDirectory()) continue;
  if (file === path.join('tests', 'validate-package.js')) continue;
  if (/\.(png|zip)$/.test(file)) continue;
  const text = fs.readFileSync(full, 'utf8');
  for (const pattern of forbidden) {
    if (pattern.test(text)) throw new Error(`Forbidden reference ${pattern} in ${file}`);
  }
}

const seed = JSON.parse(read('rules/tracker-domains.json'));
if (seed.license !== '0BSD') throw new Error('Tracker seed must be 0BSD-labeled');
const domains = [...(seed.balanced || []), ...(seed.strict || [])];
if (domains.length < 50) throw new Error('Tracker seed unexpectedly small');
for (const domain of domains) {
  if (!/^(?:[a-z0-9-]+\.)+[a-z0-9-]+$/.test(domain)) throw new Error(`Invalid domain ${domain}`);
}

for (const file of fs.readdirSync(root).filter((name) => name.endsWith('.js'))) {
  new vm.Script(read(file), { filename: file });
}
for (const file of fs.readdirSync(root).filter((name) => name.startsWith('profile-') && name.endsWith('.js'))) {
  new vm.Script(read(file), { filename: file });
}
console.log('Identity Firewall package validation passed');
