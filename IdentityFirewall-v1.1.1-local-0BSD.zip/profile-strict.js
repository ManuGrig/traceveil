if (!globalThis.IDENTITY_FIREWALL_DEFAULTS) {
  throw new Error("Identity Firewall: defaults.js must load before profile-strict.js");
}
globalThis.IDENTITY_FIREWALL_DEFAULTS = Object.freeze({
  ...globalThis.IDENTITY_FIREWALL_DEFAULTS,
  mode: "strict"
});
