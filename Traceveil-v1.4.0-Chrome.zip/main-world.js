(() => {
  "use strict";

  const bootstrap = globalThis.TRACEVEIL_DEFAULTS;
  if (!bootstrap?.modules) return;

  let config = {
    ...bootstrap,
    enabled: window.top === window ? bootstrap.enabled : false,
    modules: { ...bootstrap.modules }
  };
  delete globalThis.TRACEVEIL_DEFAULTS;

  if (window.top !== window) {
    const receiveFrameState = (event) => {
      if (event.source !== window || event.data?.source !== "traceveil-frame-state") return;
      // The page can observe and forge DOM messages. Only allow this channel to
      // activate protection; never allow page-controlled messages to turn it off.
      if (event.data.enabled !== true) return;
      config = { ...config, enabled: true };
      window.removeEventListener("message", receiveFrameState);
    };
    window.addEventListener("message", receiveFrameState);
  }

  const firstPartyOrigin = location.ancestorOrigins?.length
    ? location.ancestorOrigins[location.ancestorOrigins.length - 1]
    : location.origin;
  let host = location.hostname || "local";
  try { host = new URL(firstPartyOrigin).hostname || host; } catch {}

  const hash = (text) => {
    let value = 2166136261;
    for (let i = 0; i < text.length; i++) {
      value ^= text.charCodeAt(i);
      value = Math.imul(value, 16777619);
    }
    return value >>> 0;
  };

  const strict = config.mode === "strict";
  // Keep interference stable for a first party across reloads. The seed is
  // intentionally derived only from public, non-user-specific inputs: no raw
  // browser-session secret is exposed to the page and no per-install identifier
  // is introduced. Strict mode remains stronger through denser perturbation.
  const siteSeed = hash(`traceveil-v2:${strict ? "strict" : "balanced"}:${host}`);

  const enabled = (module) => Boolean(config.enabled && config.modules?.[module]);
  const strictEnabled = (module) => strict && enabled(module);

  // Reduce trivial wrapper detection while preserving native behavior for all
  // functions not installed by Traceveil.
  // Capture Reflect.apply before page code can shadow Function.prototype.call/apply
  // or add misleading own properties to native methods. All protected API
  // invocations below go through this immutable local reference.
  const nativeReflectApply = Reflect.apply;
  const invoke = (target, thisArg, args = []) => nativeReflectApply(target, thisArg, args);
  const nativeFunctionToString = Function.prototype.toString;
  const nativeWeakMapGet = WeakMap.prototype.get;
  const nativeWeakMapSet = WeakMap.prototype.set;
  const nativeWeakMapHas = WeakMap.prototype.has;
  const nativeWeakSetAdd = WeakSet.prototype.add;
  const nativeWeakSetHas = WeakSet.prototype.has;
  const nativeSetHas = Set.prototype.has;
  const nativeSetAdd = Set.prototype.add;
  const nativeArrayIncludes = Array.prototype.includes;
  const nativeArraySplice = Array.prototype.splice;
  const nativeArrayFilter = Array.prototype.filter;
  const nativeArrayIsArray = Array.isArray;
  const NativeString = String;
  const NativeSet = Set;
  const NativePromise = Promise;
  const nativeStringToLowerCase = String.prototype.toLowerCase;
  const nativeObjectDefineProperty = Object.defineProperty;
  const nativeObjectGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
  const nativeObjectCreate = Object.create;
  const nativeObjectFreeze = Object.freeze;
  const nativeObjectGetPrototypeOf = Object.getPrototypeOf;
  const nativeReflectOwnKeys = Reflect.ownKeys;
  const nativePromiseResolve = Promise.resolve;
  const nativePromiseThen = Promise.prototype.then;
  const weakMapGet = (map, key) => invoke(nativeWeakMapGet, map, [key]);
  const weakMapSet = (map, key, value) => invoke(nativeWeakMapSet, map, [key, value]);
  const weakMapHas = (map, key) => invoke(nativeWeakMapHas, map, [key]);
  const weakSetAdd = (set, value) => invoke(nativeWeakSetAdd, set, [value]);
  const weakSetHas = (set, value) => invoke(nativeWeakSetHas, set, [value]);
  const setHas = (set, value) => invoke(nativeSetHas, set, [value]);
  const setAdd = (set, value) => invoke(nativeSetAdd, set, [value]);
  const nativeSources = new WeakMap();
  const disguise = (wrapper, native) => {
    weakMapSet(nativeSources, wrapper, native);
    return wrapper;
  };
  const maskWithSource = (wrapper, source) => {
    weakMapSet(nativeSources, wrapper, NativeString(source));
    return wrapper;
  };
  const toStringDescriptor = nativeObjectGetOwnPropertyDescriptor(Function.prototype, "toString");
  if (toStringDescriptor?.configurable) {
    const protectedToString = disguise(function toString() {
      const native = weakMapGet(nativeSources, this);
      if (typeof native === "string") return native;
      return invoke(nativeFunctionToString, native || this);
    }, nativeFunctionToString);
    nativeObjectDefineProperty(Function.prototype, "toString", {
      ...toStringDescriptor,
      value: protectedToString
    });
  }

  const replaceGetter = (target, property, module, value, strictOnly = false) => {
    const descriptor = Object.getOwnPropertyDescriptor(target, property);
    if (!descriptor?.get || !descriptor.configurable) return;
    const protectedGetter = disguise(function () {
      const active = strictOnly ? strictEnabled(module) : enabled(module);
      if (!active) return invoke(descriptor.get, this);
      return typeof value === "function" ? invoke(value, this) : value;
    }, descriptor.get);
    Object.defineProperty(target, property, { ...descriptor, get: protectedGetter });
  };

  // Evidence-backed Windows/Chrome persona from the user's control tests.
  replaceGetter(Navigator.prototype, "hardwareConcurrency", "hardware", 8);
  if ("deviceMemory" in Navigator.prototype) replaceGetter(Navigator.prototype, "deviceMemory", "hardware", 8);
  replaceGetter(Navigator.prototype, "platform", "hardware", "Win32");

  // Keep the modern low-entropy UA-CH platform surface coherent with the
  // legacy navigator.platform Windows persona. navigator.userAgentData.platform
  // is available without a high-entropy request in Chromium, so leaving it
  // native would expose a direct JS-level contradiction on macOS/Linux.
  if (window.NavigatorUAData?.prototype) {
    replaceGetter(NavigatorUAData.prototype, "platform", "hardware", "Windows");

    if (typeof NavigatorUAData.prototype.toJSON === "function") {
      const nativeUADataToJSON = NavigatorUAData.prototype.toJSON;
      NavigatorUAData.prototype.toJSON = disguise(function () {
        const result = invoke(nativeUADataToJSON, this);
        if (!enabled("hardware") || !result || typeof result !== "object") return result;
        return { ...result, platform: "Windows" };
      }, nativeUADataToJSON);
    }
  }

  replaceGetter(Navigator.prototype, "language", "language", "en-US");
  replaceGetter(Navigator.prototype, "languages", "language", Object.freeze(["en-US", "en"]));
  // v1.4 preserves WebGPU capability and scrubs adapter identity instead of hiding navigator.gpu.

  const screenValues = Object.freeze({
    width: 1920,
    height: 1080,
    availWidth: 1920,
    availHeight: 1040,
    availTop: 0,
    availLeft: 0,
    colorDepth: 24,
    pixelDepth: 24
  });
  for (const [property, value] of Object.entries(screenValues)) {
    if (property in Screen.prototype || property in window.screen) {
      replaceGetter(Screen.prototype, property, "screen", value);
    }
  }
  if (window.ScreenOrientation) {
    replaceGetter(ScreenOrientation.prototype, "angle", "screen", 0);
    replaceGetter(ScreenOrientation.prototype, "type", "screen", "landscape-primary");
  }
  // Keep the pixel density consistent with the 1920 x 1080 non-HiDPI profile.
  // Chromium exposes devicePixelRatio as a configurable own getter on window,
  // not consistently on Window.prototype. Cover both layouts.
  if (Object.getOwnPropertyDescriptor(window, "devicePixelRatio")?.get) {
    replaceGetter(window, "devicePixelRatio", "screen", 1);
  } else if (window.Window) {
    replaceGetter(Window.prototype, "devicePixelRatio", "screen", 1);
  }

  const nextState = (state) => Math.imul(state ^ (state >>> 15), 2246822519) >>> 0;
  const perturbPixels = (data, salt) => {
    const output = new Uint8ClampedArray(data);
    const pixelCount = Math.floor(output.length / 4);
    if (!pixelCount) return output;
    const pixelStep = strict ? 1 : Math.max(1, Math.floor(pixelCount / 64));
    let state = hash(`${siteSeed}:${salt}:${output.length}`);
    for (let pixel = 0; pixel < pixelCount; pixel += pixelStep) {
      state = nextState(state);
      const index = (pixel * 4) + (state % 3);
      output[index] = Math.max(0, Math.min(255, output[index] + ((state & 8) ? 1 : -1)));
    }
    return output;
  };

  const nativeGetImageData = CanvasRenderingContext2D.prototype.getImageData;
  const nativeToDataURL = HTMLCanvasElement.prototype.toDataURL;
  const nativeToBlob = HTMLCanvasElement.prototype.toBlob;

  const cloneCanvas = (source) => {
    const clone = document.createElement("canvas");
    clone.width = source.width;
    clone.height = source.height;
    const context = clone.getContext("2d", { willReadFrequently: true });
    if (!context || !source.width || !source.height) return clone;
    context.drawImage(source, 0, 0);
    const image = invoke(nativeGetImageData, context, [0, 0, clone.width, clone.height]);
    image.data.set(perturbPixels(image.data, `${clone.width}x${clone.height}`));
    context.putImageData(image, 0, 0);
    return clone;
  };

  HTMLCanvasElement.prototype.toDataURL = disguise(function (...args) {
    if (!enabled("canvas")) return invoke(nativeToDataURL, this, args);
    try { return invoke(nativeToDataURL, cloneCanvas(this), args); }
    catch { return invoke(nativeToDataURL, this, args); }
  }, nativeToDataURL);

  HTMLCanvasElement.prototype.toBlob = disguise(function (...args) {
    if (!enabled("canvas")) return invoke(nativeToBlob, this, args);
    let target = this;
    try { target = cloneCanvas(this); } catch {}
    return invoke(nativeToBlob, target, args);
  }, nativeToBlob);

  CanvasRenderingContext2D.prototype.getImageData = disguise(function (...args) {
    const image = invoke(nativeGetImageData, this, args);
    if (enabled("canvas")) {
      try { image.data.set(perturbPixels(image.data, args.join(":"))); } catch {}
    }
    return image;
  }, nativeGetImageData);

  if (window.OffscreenCanvasRenderingContext2D) {
    const nativeOffscreenGetImageData = OffscreenCanvasRenderingContext2D.prototype.getImageData;
    const cloneOffscreenCanvas = (source) => {
      const clone = new OffscreenCanvas(source.width, source.height);
      const context = clone.getContext("2d", { willReadFrequently: true });
      if (!context || !source.width || !source.height) return clone;
      context.drawImage(source, 0, 0);
      const image = invoke(nativeOffscreenGetImageData, context, [0, 0, clone.width, clone.height]);
      image.data.set(perturbPixels(image.data, `offscreen:${clone.width}x${clone.height}`));
      context.putImageData(image, 0, 0);
      return clone;
    };
    OffscreenCanvasRenderingContext2D.prototype.getImageData = disguise(function (...args) {
      const image = invoke(nativeOffscreenGetImageData, this, args);
      if (enabled("canvas")) {
        try { image.data.set(perturbPixels(image.data, `offscreen:${args.join(":")}`)); } catch {}
      }
      return image;
    }, nativeOffscreenGetImageData);
    if (window.OffscreenCanvas?.prototype?.convertToBlob) {
      const nativeConvertToBlob = OffscreenCanvas.prototype.convertToBlob;
      OffscreenCanvas.prototype.convertToBlob = disguise(function (...args) {
        if (!enabled("canvas")) return invoke(nativeConvertToBlob, this, args);
        try { return invoke(nativeConvertToBlob, cloneOffscreenCanvas(this), args); }
        catch { return invoke(nativeConvertToBlob, this, args); }
      }, nativeConvertToBlob);
    }
    if (window.OffscreenCanvas?.prototype?.transferToImageBitmap) {
      const nativeTransferToImageBitmap = OffscreenCanvas.prototype.transferToImageBitmap;
      OffscreenCanvas.prototype.transferToImageBitmap = disguise(function (...args) {
        if (!enabled("canvas")) return invoke(nativeTransferToImageBitmap, this, args);
        try { return invoke(nativeTransferToImageBitmap, cloneOffscreenCanvas(this), args); }
        catch { return invoke(nativeTransferToImageBitmap, this, args); }
      }, nativeTransferToImageBitmap);
    }
  }

  // GPU identity protection: preserve WebGL rendering capability while
  // suppressing the debug renderer extension that exposes exact GPU identity.
  // Measured Cover Your Tracks population data showed that synthetic generic
  // strings ("WebKit" / "WebKit WebGL") were substantially rarer than the
  // v1.3.2-style unavailable result, so v1.4 returns to extension suppression.
  // The site-scoped synthetic extension farbling and WebGL pixel partitioning
  // remain enabled and are independent of this renderer-identity choice.
  const UNMASKED_VENDOR_WEBGL = 0x9245;
  const UNMASKED_RENDERER_WEBGL = 0x9246;
  const WEBGL_DEBUG_RENDERER_INFO = "webgl_debug_renderer_info";
  const WEBGL_DEBUG_SHADERS = "webgl_debug_shaders";
  const GPU_FAKE_EXTENSIONS = nativeObjectFreeze([
    "EXT_buffer_residency", "EXT_command_budget", "EXT_context_priority", "EXT_frame_pacing",
    "EXT_image_residency", "EXT_mesh_budget", "EXT_pipeline_cache_hint", "EXT_pipeline_residency",
    "EXT_render_budget", "EXT_resource_priority", "EXT_shader_cache_hint", "EXT_shader_residency",
    "EXT_surface_priority", "EXT_texture_budget", "EXT_texture_residency", "EXT_tile_residency",
    "WEBGL_buffer_budget", "WEBGL_context_priority_hint", "WEBGL_frame_pacing_hint",
    "WEBGL_pipeline_cache_hint", "WEBGL_render_budget", "WEBGL_resource_priority_hint",
    "WEBGL_shader_cache_hint", "WEBGL_surface_priority_hint", "WEBGL_texture_budget", "WEBGL_tile_residency"
  ]);
  const gpuExtensionSeed = hash(`traceveil-gpu-v2:${siteSeed}:${host}`);
  const syntheticWebGLExtension = GPU_FAKE_EXTENSIONS[gpuExtensionSeed % GPU_FAKE_EXTENSIONS.length];

  const extensionInterfaceName = (extensionName) => String(extensionName)
    .toLowerCase()
    .split("_")
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join("");

  const makeSyntheticExtension = (extensionName) => {
    const interfaceName = extensionInterfaceName(extensionName);
    const SyntheticExtension = function WebGLExtension() {};
    try { nativeObjectDefineProperty(SyntheticExtension, "name", { value: interfaceName, configurable: true }); } catch {}
    maskWithSource(SyntheticExtension, `function ${interfaceName}() { [native code] }`);
    const prototype = nativeObjectCreate(Object.prototype);
    try {
      nativeObjectDefineProperty(prototype, "constructor", {
        value: SyntheticExtension, writable: true, configurable: true, enumerable: false
      });
      if (typeof Symbol === "function" && Symbol.toStringTag) {
        nativeObjectDefineProperty(prototype, Symbol.toStringTag, {
          value: interfaceName, configurable: true, enumerable: false
        });
      }
    } catch {}
    try { nativeObjectFreeze(prototype); } catch {}
    const object = nativeObjectCreate(prototype);
    try { nativeObjectFreeze(object); } catch {}
    return object;
  };

  const patchWebGL = (prototype) => {
    if (!prototype) return;
    const nativeGetExtension = prototype.getExtension;
    const nativeGetSupportedExtensions = prototype.getSupportedExtensions;
    const nativeGetParameter = prototype.getParameter;
    const nativeReadPixels = prototype.readPixels;
    if (!nativeGetExtension || !nativeGetParameter) return;

    const syntheticObjects = new WeakMap();

    prototype.getExtension = disguise(function (name) {
      if (!enabled("webgl")) return invoke(nativeGetExtension, this, [name]);
      const normalizedName = invoke(nativeStringToLowerCase, NativeString(name));
      if (normalizedName === invoke(nativeStringToLowerCase, syntheticWebGLExtension)) {
        let synthetic = weakMapGet(syntheticObjects, this);
        if (!synthetic) {
          synthetic = makeSyntheticExtension(syntheticWebGLExtension);
          weakMapSet(syntheticObjects, this, synthetic);
        }
        return synthetic;
      }
      if (normalizedName === WEBGL_DEBUG_RENDERER_INFO || normalizedName === WEBGL_DEBUG_SHADERS) return null;
      return invoke(nativeGetExtension, this, [name]);
    }, nativeGetExtension);

    if (nativeGetSupportedExtensions) {
      prototype.getSupportedExtensions = disguise(function () {
        const extensions = invoke(nativeGetSupportedExtensions, this);
        if (!enabled("webgl") || !nativeArrayIsArray(extensions)) return extensions;
        const output = invoke(nativeArrayFilter, extensions, [(name) => {
          const normalizedName = invoke(nativeStringToLowerCase, NativeString(name));
          return normalizedName !== WEBGL_DEBUG_RENDERER_INFO && normalizedName !== WEBGL_DEBUG_SHADERS;
        }]);
        if (!invoke(nativeArrayIncludes, output, [syntheticWebGLExtension])) {
          const insertAt = output.length ? gpuExtensionSeed % (output.length + 1) : 0;
          invoke(nativeArraySplice, output, [insertAt, 0, syntheticWebGLExtension]);
        }
        return output;
      }, nativeGetSupportedExtensions);
    }

    // Protect callers that hard-code the debug enum values instead of first
    // enabling WEBGL_debug_renderer_info. Invoke the native method first so
    // Chrome can preserve its normal INVALID_ENUM/error-state behavior when
    // the hidden extension is not enabled, then suppress any returned identity.
    prototype.getParameter = disguise(function (parameter) {
      if (enabled("webgl") && (parameter === UNMASKED_VENDOR_WEBGL || parameter === UNMASKED_RENDERER_WEBGL)) {
        try { invoke(nativeGetParameter, this, [parameter]); } catch {}
        return null;
      }
      return invoke(nativeGetParameter, this, [parameter]);
    }, nativeGetParameter);

    if (nativeReadPixels) {
      prototype.readPixels = disguise(function (...args) {
        const result = invoke(nativeReadPixels, this, args);
        const pixels = args[6];
        if (enabled("webgl") && (pixels instanceof Uint8Array || pixels instanceof Uint8ClampedArray)) {
          try { pixels.set(perturbPixels(pixels, `webgl:${args[2]}x${args[3]}`).subarray(0, pixels.length)); } catch {}
        }
        return result;
      }, nativeReadPixels);
    }
  };
  patchWebGL(window.WebGLRenderingContext?.prototype);
  patchWebGL(window.WebGL2RenderingContext?.prototype);

  // WebGPU is kept available in v1.4. Where Chrome exposes adapter identity
  // through GPUAdapter.info or requestAdapterInfo(), Traceveil returns a
  // same-prototype scrubbed view instead of Proxying immutable WebIDL fields.
  const webGPUInfoCache = new WeakMap();
  const scrubWebGPUInfo = (info) => {
    if (!info || (typeof info !== "object" && typeof info !== "function")) return info;
    if (weakMapHas(webGPUInfoCache, info)) return weakMapGet(webGPUInfoCache, info);
    const sensitive = new NativeSet(["vendor", "architecture", "device", "description"]);
    const copied = new NativeSet();
    let view;
    try { view = nativeObjectCreate(nativeObjectGetPrototypeOf(info)); } catch { view = {}; }
    let keys = [];
    try { keys = invoke(nativeReflectOwnKeys, Reflect, [info]); } catch {}
    for (const property of keys) {
      let descriptor;
      try { descriptor = nativeObjectGetOwnPropertyDescriptor(info, property); } catch {}
      if (!descriptor) continue;
      if (typeof property === "string" && setHas(sensitive, property)) {
        setAdd(copied, property);
        descriptor = { value: "", writable: false, enumerable: descriptor.enumerable, configurable: descriptor.configurable };
      }
      try { nativeObjectDefineProperty(view, property, descriptor); } catch {}
    }
    for (const property of sensitive) {
      if (setHas(copied, property)) continue;
      try { nativeObjectDefineProperty(view, property, { value: "", writable: false, enumerable: true, configurable: true }); } catch {}
    }
    weakMapSet(webGPUInfoCache, info, view);
    return view;
  };

  const patchWebGPU = () => {
    const prototype = window.GPUAdapter?.prototype;
    if (!prototype) return;

    const infoDescriptor = nativeObjectGetOwnPropertyDescriptor(prototype, "info");
    if (infoDescriptor?.get && infoDescriptor.configurable) {
      const nativeGetInfo = infoDescriptor.get;
      const protectedInfo = disguise(function () {
        const info = invoke(nativeGetInfo, this);
        return enabled("webgpu") ? scrubWebGPUInfo(info) : info;
      }, nativeGetInfo);
      try { nativeObjectDefineProperty(prototype, "info", { ...infoDescriptor, get: protectedInfo }); } catch {}
    }

    const requestDescriptor = nativeObjectGetOwnPropertyDescriptor(prototype, "requestAdapterInfo");
    if (requestDescriptor?.value && requestDescriptor.configurable) {
      const nativeRequestAdapterInfo = requestDescriptor.value;
      const protectedRequestAdapterInfo = disguise(function (...args) {
        const promise = invoke(nativeRequestAdapterInfo, this, args);
        if (!enabled("webgpu")) return promise;
        const resolved = invoke(nativePromiseResolve, NativePromise, [promise]);
        return invoke(nativePromiseThen, resolved, [(info) => scrubWebGPUInfo(info)]);
      }, nativeRequestAdapterInfo);
      try { nativeObjectDefineProperty(prototype, "requestAdapterInfo", { ...requestDescriptor, value: protectedRequestAdapterInfo }); } catch {}
    }
  };
  patchWebGPU();

  const perturbFloats = (array, salt) => {
    if (!array?.length) return;
    let state = hash(`${siteSeed}:${salt}:${array.length}`);
    const step = strict ? 16 : 97;
    for (let i = 0; i < array.length; i += step) {
      state = nextState(state);
      array[i] += (state & 1) ? 1e-5 : -1e-5;
    }
  };

  const seenAudio = new WeakSet();
  const nativeChannelData = AudioBuffer.prototype.getChannelData;
  AudioBuffer.prototype.getChannelData = disguise(function (channel) {
    const data = invoke(nativeChannelData, this, [channel]);
    if (enabled("audio") && !seenAudio.has(data)) {
      seenAudio.add(data);
      perturbFloats(data, `channel:${channel}`);
    }
    return data;
  }, nativeChannelData);

  if (AudioBuffer.prototype.copyFromChannel) {
    const nativeCopyFromChannel = AudioBuffer.prototype.copyFromChannel;
    AudioBuffer.prototype.copyFromChannel = disguise(function (destination, channel, startInChannel) {
      const result = invoke(nativeCopyFromChannel, this, [destination, channel, startInChannel]);
      if (enabled("audio")) perturbFloats(destination, `copy:${channel}:${startInChannel || 0}`);
      return result;
    }, nativeCopyFromChannel);
  }

  if (window.AnalyserNode) {
    for (const method of ["getFloatFrequencyData", "getFloatTimeDomainData"]) {
      const native = AnalyserNode.prototype[method];
      if (!native) continue;
      AnalyserNode.prototype[method] = disguise(function (array) {
        const result = invoke(native, this, [array]);
        if (enabled("audio")) perturbFloats(array, method);
        return result;
      }, native);
    }
    for (const method of ["getByteFrequencyData", "getByteTimeDomainData"]) {
      const native = AnalyserNode.prototype[method];
      if (!native) continue;
      AnalyserNode.prototype[method] = disguise(function (array) {
        const result = invoke(native, this, [array]);
        if (enabled("audio") && array?.length) {
          const index = siteSeed % array.length;
          array[index] = Math.max(0, Math.min(255, array[index] + ((siteSeed & 1) ? 1 : -1)));
        }
        return result;
      }, native);
    }
  }

  const TARGET_TIMEZONE = "America/New_York";
  const NativeDateTimeFormat = window.Intl?.DateTimeFormat;
  const MONTH_ABBR = Object.freeze([
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  ]);

  // Apply the target only when the caller did not explicitly request a zone.
  // Explicit zone-aware UI therefore continues to receive its requested zone.
  const withTargetTimeZone = (options) => (
    enabled("timezone") && !options?.timeZone
      ? { ...(options || {}), timeZone: TARGET_TIMEZONE }
      : options
  );

  const zoneParts = (date, timeZone) => {
    if (!NativeDateTimeFormat) return null;
    try {
      const formatter = new NativeDateTimeFormat("en-US", {
        timeZone,
        hourCycle: "h23",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        weekday: "short",
        timeZoneName: "long"
      });
      return Object.fromEntries(
        formatter.formatToParts(date).map((part) => [part.type, part.value])
      );
    } catch {
      return null;
    }
  };

  // Ask the native Intl engine for the exact wall clock at this instant. This
  // keeps the offset DST-correct without duplicating mutable timezone rules.
  const zoneOffsetMinutes = (date, timeZone) => {
    const parts = zoneParts(date, timeZone);
    if (!parts) return null;
    const asUTC = Date.UTC(
      Number(parts.year),
      Number(parts.month) - 1,
      Number(parts.day),
      Number(parts.hour),
      Number(parts.minute),
      Number(parts.second)
    );
    return Math.round((date.getTime() - asUTC) / 60000);
  };

  const gmtOffsetLabel = (offsetMinutes) => {
    const sign = offsetMinutes > 0 ? "-" : "+";
    const absolute = Math.abs(offsetMinutes);
    const hours = String(Math.floor(absolute / 60)).padStart(2, "0");
    const minutes = String(absolute % 60).padStart(2, "0");
    return `GMT${sign}${hours}${minutes}`;
  };

  const buildDateTimeString = (date) => {
    const parts = zoneParts(date, TARGET_TIMEZONE);
    const offset = zoneOffsetMinutes(date, TARGET_TIMEZONE);
    if (!parts || offset === null) return null;
    return {
      date: `${parts.weekday} ${MONTH_ABBR[Number(parts.month) - 1]} ${parts.day} ${parts.year}`,
      time: `${parts.hour}:${parts.minute}:${parts.second} ${gmtOffsetLabel(offset)} (${parts.timeZoneName})`
    };
  };

  if (NativeDateTimeFormat) {
    const handler = {
      construct(target, args, newTarget) {
        return Reflect.construct(
          target,
          [args[0], withTargetTimeZone(args[1])],
          newTarget
        );
      },
      apply(target, thisArg, args) {
        return invoke(target, thisArg, [args[0], withTargetTimeZone(args[1])]);
      }
    };
    Intl.DateTimeFormat = disguise(new Proxy(NativeDateTimeFormat, handler), NativeDateTimeFormat);
  }

  const nativeGetTimezoneOffset = Date.prototype.getTimezoneOffset;
  Date.prototype.getTimezoneOffset = disguise(function () {
    if (!enabled("timezone")) return invoke(nativeGetTimezoneOffset, this);
    const offset = zoneOffsetMinutes(this, TARGET_TIMEZONE);
    return offset === null ? invoke(nativeGetTimezoneOffset, this) : offset;
  }, nativeGetTimezoneOffset);

  const nativeDateToString = Date.prototype.toString;
  Date.prototype.toString = disguise(function () {
    if (!enabled("timezone")) return invoke(nativeDateToString, this);
    const result = buildDateTimeString(this);
    return result ? `${result.date} ${result.time}` : invoke(nativeDateToString, this);
  }, nativeDateToString);

  const nativeDateToDateString = Date.prototype.toDateString;
  Date.prototype.toDateString = disguise(function () {
    if (!enabled("timezone")) return invoke(nativeDateToDateString, this);
    const result = buildDateTimeString(this);
    return result ? result.date : invoke(nativeDateToDateString, this);
  }, nativeDateToDateString);

  const nativeDateToTimeString = Date.prototype.toTimeString;
  Date.prototype.toTimeString = disguise(function () {
    if (!enabled("timezone")) return invoke(nativeDateToTimeString, this);
    const result = buildDateTimeString(this);
    return result ? result.time : invoke(nativeDateToTimeString, this);
  }, nativeDateToTimeString);

  const nativeToLocaleString = Date.prototype.toLocaleString;
  Date.prototype.toLocaleString = disguise(function (locales, options) {
    return invoke(nativeToLocaleString, this, [locales, withTargetTimeZone(options)]);
  }, nativeToLocaleString);

  const nativeToLocaleDateString = Date.prototype.toLocaleDateString;
  Date.prototype.toLocaleDateString = disguise(function (locales, options) {
    return invoke(nativeToLocaleDateString, this, [locales, withTargetTimeZone(options)]);
  }, nativeToLocaleDateString);

  const nativeToLocaleTimeString = Date.prototype.toLocaleTimeString;
  Date.prototype.toLocaleTimeString = disguise(function (locales, options) {
    return invoke(nativeToLocaleTimeString, this, [locales, withTargetTimeZone(options)]);
  }, nativeToLocaleTimeString);

  if (strictEnabled("clientHints") && window.NavigatorUAData?.prototype?.getHighEntropyValues) {
    const nativeGetHighEntropyValues = NavigatorUAData.prototype.getHighEntropyValues;
    NavigatorUAData.prototype.getHighEntropyValues = disguise(async function (hints) {
      const result = await invoke(nativeGetHighEntropyValues, this, [hints]);
      const requested = new Set(Array.isArray(hints) ? hints : []);
      if (requested.has("architecture")) result.architecture = "x86";
      if (requested.has("bitness")) result.bitness = "64";
      if (requested.has("model")) result.model = "";
      if (requested.has("platformVersion")) result.platformVersion = "10.0.0";
      if (requested.has("wow64")) result.wow64 = false;
      if (requested.has("uaFullVersion") && result.uaFullVersion) {
        result.uaFullVersion = `${String(result.uaFullVersion).split(".")[0]}.0.0.0`;
      }
      if (requested.has("fullVersionList") && Array.isArray(result.fullVersionList)) {
        result.fullVersionList = result.fullVersionList.map((item) => ({
          brand: item.brand,
          version: `${String(item.version).split(".")[0]}.0.0.0`
        }));
      }
      return result;
    }, nativeGetHighEntropyValues);
  }

  if (strictEnabled("battery") && typeof Navigator.prototype.getBattery === "function") {
    const nativeGetBattery = Navigator.prototype.getBattery;
    const battery = Object.freeze({
      charging: true,
      chargingTime: 0,
      dischargingTime: Infinity,
      level: 1,
      onchargingchange: null,
      onchargingtimechange: null,
      ondischargingtimechange: null,
      onlevelchange: null,
      addEventListener() {},
      removeEventListener() {},
      dispatchEvent() { return true; }
    });
    Navigator.prototype.getBattery = disguise(function () {
      return Promise.resolve(battery);
    }, nativeGetBattery);
  }

  const commonFonts = new Set([
    "arial", "courier new", "georgia", "segoe ui", "tahoma", "times new roman",
    "trebuchet ms", "verdana", "serif", "sans-serif", "monospace", "system-ui"
  ]);
  const fontFamilies = (font) => {
    const value = String(font || "").replace(/^.*?(?:px|pt|em|rem|%)\s+/i, "");
    return value.split(",").map((item) => item.trim().replace(/^['"]|['"]$/g, "").toLowerCase()).filter(Boolean);
  };
  const hasUncommonFont = (font) => fontFamilies(font).some((family) => !commonFonts.has(family));
  const genericFonts = new Set(["serif", "sans-serif", "monospace", "system-ui"]);
  const fallbackFont = (font) => {
    const families = fontFamilies(font);
    return families.find((family) => genericFonts.has(family)) || "sans-serif";
  };

  if (strictEnabled("fonts")) {
    if (window.FontFaceSet?.prototype?.check) {
      const nativeFontCheck = FontFaceSet.prototype.check;
      FontFaceSet.prototype.check = disguise(function (font, text) {
        if (hasUncommonFont(font)) return false;
        return invoke(nativeFontCheck, this, [font, text]);
      }, nativeFontCheck);
    }

    const canvasFont = Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype, "font");
    if (canvasFont?.set && canvasFont.configurable) {
      const protectedFontSetter = disguise(function (value) {
        const normalized = hasUncommonFont(value)
          ? String(value).replace(/((?:px|pt|em|rem|%)\s+).+$/i, (_match, prefix) => `${prefix}${fallbackFont(value)}`)
          : value;
        return invoke(canvasFont.set, this, [normalized]);
      }, canvasFont.set);
      Object.defineProperty(CanvasRenderingContext2D.prototype, "font", {
        ...canvasFont,
        set: protectedFontSetter
      });
    }

    const looksLikeFontProbe = (element) => {
      const style = element?.style;
      if (!style?.fontFamily || !hasUncommonFont(style.fontFamily)) return false;
      return style.position === "absolute" || style.position === "fixed" ||
        style.visibility === "hidden" || /^-\d/.test(style.left || style.top || "") ||
        element.getAttribute?.("aria-hidden") === "true";
    };
    const withFallbackFont = (element, read) => {
      if (!looksLikeFontProbe(element)) return read();
      const original = element.style.fontFamily;
      try {
        element.style.fontFamily = fallbackFont(original);
        return read();
      } finally {
        element.style.fontFamily = original;
      }
    };

    for (const property of ["offsetWidth", "offsetHeight"]) {
      const descriptor = Object.getOwnPropertyDescriptor(HTMLElement.prototype, property);
      if (!descriptor?.get || !descriptor.configurable) continue;
      const protectedGetter = disguise(function () {
        return withFallbackFont(this, () => invoke(descriptor.get, this));
      }, descriptor.get);
      Object.defineProperty(HTMLElement.prototype, property, { ...descriptor, get: protectedGetter });
    }
    for (const method of ["getBoundingClientRect", "getClientRects"]) {
      const native = Element.prototype[method];
      if (!native) continue;
      Element.prototype[method] = disguise(function (...args) {
        return withFallbackFont(this, () => invoke(native, this, args));
      }, native);
    }
    if (window.Range) {
      for (const method of ["getBoundingClientRect", "getClientRects"]) {
        const native = Range.prototype[method];
        if (!native) continue;
        Range.prototype[method] = disguise(function (...args) {
          const container = this.commonAncestorContainer;
          const element = container?.nodeType === 1 ? container : container?.parentElement;
          return withFallbackFont(element, () => invoke(native, this, args));
        }, native);
      }
    }
  }
})();
