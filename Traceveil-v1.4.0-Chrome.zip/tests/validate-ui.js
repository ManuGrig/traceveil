#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

const manifest = JSON.parse(read("manifest.json"));
const html = read("popup.html");
const css = read("popup.css");
const popup = read("popup.js");
const main = read("main-world.js");

for (const required of [
  'id="enabled"', 'id="siteEnabled"', 'id="balancedMode"', 'id="strictMode"',
  'id="fingerprintModules"', 'id="networkModules"', 'id="excludedSites"',
  'data-panel="overviewPanel"', 'data-panel="protectionPanel"', 'data-panel="networkPanel"',
  'data-panel="sitesPanel"', 'data-panel="aboutPanel"', 'assets/traceveil-logo.png'
]) {
  if (!html.includes(required)) throw new Error(`Popup missing required control/section: ${required}`);
}
if (!html.includes(`v${manifest.version_name}`)) throw new Error("Popup version does not match manifest version_name");
if (html.includes("PRE-RELEASE")) throw new Error("Stable popup must not contain PRE-RELEASE labeling");
if (!html.includes('<span class="version-badge">v1.4</span>')) throw new Error("Stable popup version badge is missing");
if (!css.includes("--cyan: #229ca9") || !css.includes("--bg: #0b1017")) {
  throw new Error("New Traceveil/Lens Guard visual tokens are missing");
}

const context = vm.createContext({ globalThis: {} });
vm.runInContext(read("defaults.js"), context, { filename: "defaults.js" });
const defaults = context.globalThis.TRACEVEIL_DEFAULTS;
if (!defaults?.modules) throw new Error("Could not load Traceveil defaults");

const uiKeys = new Set([...popup.matchAll(/\bkey:\s*"([A-Za-z0-9]+)"/g)].map((match) => match[1]));
for (const key of Object.keys(defaults.modules)) {
  if (!uiKeys.has(key)) throw new Error(`Module ${key} exists in defaults but is missing from the popup UI`);
}
for (const key of uiKeys) {
  if (!(key in defaults.modules)) throw new Error(`Popup exposes unknown module ${key}`);
}

function extractPool(source) {
  const match = source.match(/GPU_FAKE_EXTENSIONS\s*=\s*(?:Object\.freeze|nativeObjectFreeze)\(\[([\s\S]*?)\]\)/);
  if (!match) throw new Error("GPU fake-extension pool not found");
  return [...match[1].matchAll(/"([A-Za-z0-9_]+)"/g)].map((item) => item[1]);
}
const mainPool = extractPool(main);
const popupPool = extractPool(popup);
if (mainPool.length < 20) throw new Error("GPU synthetic-extension pool unexpectedly small");
if (JSON.stringify(mainPool) !== JSON.stringify(popupPool)) {
  throw new Error("Popup and main-world GPU fake-extension pools differ");
}

if (!popup.includes('chrome.runtime.sendMessage({ type: "sync-config" })')) {
  throw new Error("Popup settings are not wired to the v1.3.2 sync path");
}
if (!popup.includes('type: "standardize-window"')) {
  throw new Error("Strict-mode window standardization control is not wired");
}
if (!popup.includes('chrome.runtime.sendMessage({ type: "get-tracker-state" })')) {
  throw new Error("Tracker-state UI is not wired");
}

console.log("Traceveil UI validation passed");
