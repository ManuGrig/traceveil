#!/usr/bin/env node
"use strict";

/**
 * End-to-end verification in a real Chrome instance.
 *
 * The harness uses Puppeteer's extension-install API when available and falls
 * back to Chrome's legacy unpacked-extension flags. It verifies exact normalized
 * targets, on/off interference, early-vs-late stability, reload stability,
 * first-party separation, per-site exclusions, and absence of the rejected raw
 * session-seed message channel.
 *
 * Install: npm install
 * Run:     npm run verify
 * Optional environment variables:
 *   TRACEVEIL_CHROME_PATH=/path/to/chrome
 *   TRACEVEIL_HEADLESS=0          (use a visible browser for legacy fallback)
 *   TRACEVEIL_NO_SANDBOX=1        (containers only)
 */

const fs = require("fs");
const http = require("http");
const os = require("os");
const path = require("path");

const EXTENSION_PATH = path.resolve(__dirname, "..");
const PASS = [];
const FAIL = [];
const SKIP = [];

const check = (label, condition, detail = "") => {
  if (condition) {
    PASS.push(label);
    console.log(`  ok  - ${label}`);
  } else {
    FAIL.push(label);
    console.log(`FAIL  - ${label}${detail ? ` (${detail})` : ""}`);
  }
};

const skip = (label, detail) => {
  SKIP.push(label);
  console.log(`  --  - ${label}${detail ? ` (${detail})` : ""}`);
};

const snapshotFunction = String(function traceveilSnapshot() {
  const hashBytes = (bytes) => {
    let value = 2166136261;
    for (const byte of bytes) {
      value ^= byte;
      value = Math.imul(value, 16777619);
    }
    return (value >>> 0).toString(16).padStart(8, "0");
  };

  const canvas = document.createElement("canvas");
  canvas.width = 200;
  canvas.height = 50;
  const context = canvas.getContext("2d", { willReadFrequently: true });
  context.textBaseline = "top";
  context.font = "16px Arial";
  context.fillStyle = "#f60";
  context.fillRect(0, 0, 100, 30);
  context.fillStyle = "#069";
  context.fillText("Traceveil fingerprint test, 你好", 2, 15);
  const canvasHash = hashBytes(new TextEncoder().encode(canvas.toDataURL()));

  let webglHash = null;
  let webglDebugVendor = "unavailable";
  let webglDebugRenderer = "unavailable";
  let webglSyntheticExtension = null;
  try {
    const glCanvas = document.createElement("canvas");
    glCanvas.width = 32;
    glCanvas.height = 32;
    const gl = glCanvas.getContext("webgl", { preserveDrawingBuffer: true });
    if (gl) {
      gl.clearColor(0.15, 0.35, 0.55, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
      const pixels = new Uint8Array(32 * 32 * 4);
      gl.readPixels(0, 0, 32, 32, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
      webglHash = hashBytes(pixels);
      const debugInfo = gl.getExtension("WEBGL_debug_renderer_info");
      webglDebugVendor = debugInfo
        ? gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL)
        : null;
      webglDebugRenderer = debugInfo
        ? gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL)
        : null;
      const supportedExtensions = gl.getSupportedExtensions() || [];
      var webglDebugRendererAdvertised = supportedExtensions.some((name) => String(name).toLowerCase() === "webgl_debug_renderer_info");
      const syntheticPool = [
        "EXT_buffer_residency", "EXT_command_budget", "EXT_context_priority", "EXT_frame_pacing",
        "EXT_image_residency", "EXT_mesh_budget", "EXT_pipeline_cache_hint", "EXT_pipeline_residency",
        "EXT_render_budget", "EXT_resource_priority", "EXT_shader_cache_hint", "EXT_shader_residency",
        "EXT_surface_priority", "EXT_texture_budget", "EXT_texture_residency", "EXT_tile_residency",
        "WEBGL_buffer_budget", "WEBGL_context_priority_hint", "WEBGL_frame_pacing_hint",
        "WEBGL_pipeline_cache_hint", "WEBGL_render_budget", "WEBGL_resource_priority_hint",
        "WEBGL_shader_cache_hint", "WEBGL_surface_priority_hint", "WEBGL_texture_budget", "WEBGL_tile_residency"
      ];
      webglSyntheticExtension = supportedExtensions.find((name) => syntheticPool.includes(name)) || null;
    }
  } catch {
    webglDebugVendor = "error";
    webglDebugRenderer = "error";
  }

  let audioHash = null;
  try {
    const AudioContextType = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    if (AudioContextType) {
      const audioContext = new AudioContextType(1, 512, 44100);
      const buffer = audioContext.createBuffer(1, 512, 44100);
      const source = new Float32Array(512);
      for (let index = 0; index < source.length; index++) source[index] = Math.sin(index / 7);
      buffer.copyToChannel(source, 0);
      const destination = new Float32Array(512);
      buffer.copyFromChannel(destination, 0);
      audioHash = hashBytes(new Uint8Array(destination.buffer));
    }
  } catch {
    audioHash = null;
  }

  const july = new Date(Date.UTC(2026, 6, 10, 12, 0, 0));
  const january = new Date(Date.UTC(2026, 0, 10, 12, 0, 0));

  return {
    hardwareConcurrency: navigator.hardwareConcurrency,
    deviceMemory: navigator.deviceMemory,
    platform: navigator.platform,
    uaPlatform: navigator.userAgentData?.platform ?? null,
    uaJSONPlatform: navigator.userAgentData?.toJSON?.().platform ?? null,
    language: navigator.language,
    languages: Array.from(navigator.languages || []),
    screenWidth: screen.width,
    screenHeight: screen.height,
    colorDepth: screen.colorDepth,
    devicePixelRatio: window.devicePixelRatio,
    timezoneOffsetJuly: july.getTimezoneOffset(),
    timezoneOffsetJanuary: january.getTimezoneOffset(),
    dateStringJuly: july.toString(),
    intlTimeZone: new Intl.DateTimeFormat().resolvedOptions().timeZone,
    intlExplicitLondon: new Intl.DateTimeFormat("en-US", { timeZone: "Europe/London" }).resolvedOptions().timeZone,
    canvasHash,
    webglHash,
    webglDebugVendor,
    webglDebugRenderer,
    webglDebugRendererAdvertised: typeof webglDebugRendererAdvertised === "boolean" ? webglDebugRendererAdvertised : null,
    webglSyntheticExtension,
    webgpuAvailable: typeof navigator.gpu !== "undefined",
    audioHash,
    traceveilMessages: Array.isArray(window.__traceveilMessages) ? window.__traceveilMessages : []
  };
});

const testHtml = `<!doctype html>
<html><head><meta charset="utf-8"><title>Traceveil verification</title>
<script>
window.__traceveilMessages = [];
window.addEventListener("message", (event) => {
  if (typeof event.data?.source === "string" && event.data.source.startsWith("traceveil-")) {
    window.__traceveilMessages.push(event.data);
  }
});
window.traceveilSnapshot = (${snapshotFunction});
window.__traceveilEarly = window.traceveilSnapshot();
</script></head><body>Traceveil verification</body></html>`;

const startTestServer = () => new Promise((resolve, reject) => {
  const server = http.createServer((_request, response) => {
    response.writeHead(200, {
      "content-type": "text/html; charset=utf-8",
      "cache-control": "no-store"
    });
    response.end(testHtml);
  });
  server.once("error", reject);
  server.listen(0, "127.0.0.1", () => {
    const { port } = server.address();
    resolve({
      server,
      primaryUrl: `http://127.0.0.1:${port}/`,
      alternateUrl: `http://localhost:${port}/`
    });
  });
});

const existingPath = (candidate) => candidate && fs.existsSync(candidate) ? candidate : null;
const findChrome = (puppeteer) => {
  const explicit = existingPath(process.env.TRACEVEIL_CHROME_PATH || process.env.PUPPETEER_EXECUTABLE_PATH);
  if (explicit) return explicit;
  try {
    const bundled = puppeteer.executablePath();
    if (existingPath(bundled)) return bundled;
  } catch {}

  const candidates = process.platform === "win32"
    ? [
        path.join(process.env.PROGRAMFILES || "", "Google/Chrome/Application/chrome.exe"),
        path.join(process.env["PROGRAMFILES(X86)"] || "", "Google/Chrome/Application/chrome.exe"),
        path.join(process.env.LOCALAPPDATA || "", "Google/Chrome/Application/chrome.exe")
      ]
    : process.platform === "darwin"
      ? ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "/Applications/Chromium.app/Contents/MacOS/Chromium"]
      : ["/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/usr/bin/chromium", "/usr/bin/chromium-browser"];
  return candidates.map(existingPath).find(Boolean) || null;
};

const launchArgs = () => process.env.TRACEVEIL_NO_SANDBOX === "1"
  ? ["--no-sandbox", "--disable-setuid-sandbox"]
  : [];

const waitForLegacyExtensionId = async (browser) => {
  const existing = browser.targets().find((target) =>
    target.type() === "service_worker" && target.url().includes("service-worker.js")
  );
  const target = existing || await browser.waitForTarget(
    (candidate) => candidate.type() === "service_worker" && candidate.url().includes("service-worker.js"),
    { timeout: 15000 }
  );
  return new URL(target.url()).host;
};

const launchBrowser = async (puppeteer, executablePath) => {
  const common = {
    executablePath,
    args: launchArgs(),
    timeout: 45000
  };

  let browser;
  try {
    browser = await puppeteer.launch({ ...common, headless: true, enableExtensions: true });
    const extensionId = await browser.installExtension(EXTENSION_PATH);
    return { browser, extensionId, method: "Puppeteer Extensions API" };
  } catch (modernError) {
    if (browser) await browser.close().catch(() => {});
    const headless = process.env.TRACEVEIL_HEADLESS === "1";
    const args = [
      ...launchArgs(),
      `--disable-extensions-except=${EXTENSION_PATH}`,
      `--load-extension=${EXTENSION_PATH}`
    ];
    try {
      browser = await puppeteer.launch({ executablePath, headless, args, timeout: 45000 });
      const extensionId = await waitForLegacyExtensionId(browser);
      return { browser, extensionId, method: "legacy unpacked-extension flags" };
    } catch (legacyError) {
      if (browser) await browser.close().catch(() => {});
      const message = [
        "Chrome could not load the unpacked extension through either supported test path.",
        `Modern API: ${modernError.message}`,
        `Legacy flags: ${legacyError.message}`,
        "Use the Chrome downloaded by `npm install`, set TRACEVEIL_CHROME_PATH to Google Chrome,",
        "or run the legacy fallback with a desktop session (TRACEVEIL_HEADLESS=0)."
      ].join("\n");
      throw new Error(message);
    }
  }
};

const BASE_MODULES = {
  canvas: true,
  webgl: true,
  webgpu: true,
  audio: true,
  hardware: true,
  screen: true,
  language: true,
  timezone: true,
  clientHints: true,
  fonts: false,
  battery: true,
  webRTC: true,
  trackerBlocking: true,
  trackingParams: true,
  privacySandbox: true,
  thirdPartyCookies: true,
  networkPrediction: true
};

const applyConfig = async (browser, extensionId, config) => {
  const page = await browser.newPage();
  try {
    await page.goto(`chrome-extension://${extensionId}/popup.html`, { waitUntil: "domcontentloaded" });
    const response = await page.evaluate(async (nextConfig) => {
      await chrome.storage.local.clear();
      await chrome.storage.local.set(nextConfig);
      return chrome.runtime.sendMessage({ type: "sync-config" });
    }, config);
    if (!response?.ok) throw new Error(response?.error || "Extension sync failed");
  } finally {
    await page.close();
  }
};

const readFingerprint = async (browser, url) => {
  const page = await browser.newPage();
  try {
    await page.goto(url, { waitUntil: "domcontentloaded" });
    const result = await page.evaluate(() => ({
      early: window.__traceveilEarly,
      late: window.traceveilSnapshot()
    }));
    return result;
  } finally {
    await page.close();
  }
};

const sameInterference = (left, right) =>
  left.canvasHash === right.canvasHash &&
  (left.webglHash === null || right.webglHash === null || left.webglHash === right.webglHash) &&
  (left.audioHash === null || right.audioHash === null || left.audioHash === right.audioHash);

async function main() {
  let puppeteer;
  try {
    puppeteer = require("puppeteer");
  } catch {
    console.error('Missing test dependency. Run "npm install" first.');
    process.exit(1);
  }

  const executablePath = findChrome(puppeteer);
  if (!executablePath) {
    throw new Error("No compatible Chrome executable found. Run npm install or set TRACEVEIL_CHROME_PATH.");
  }

  const { server, primaryUrl, alternateUrl } = await startTestServer();
  let browser;
  try {
    const launched = await launchBrowser(puppeteer, executablePath);
    browser = launched.browser;
    console.log(`Chrome: ${executablePath}`);
    console.log(`Extension: ${launched.extensionId} via ${launched.method}\n`);

    await applyConfig(browser, launched.extensionId, {
      enabled: false,
      mode: "balanced",
      disabledSites: [],
      modules: BASE_MODULES
    });
    const off = await readFingerprint(browser, primaryUrl);

    await applyConfig(browser, launched.extensionId, {
      enabled: true,
      mode: "balanced",
      disabledSites: [],
      modules: BASE_MODULES
    });
    const balanced = await readFingerprint(browser, primaryUrl);

    await applyConfig(browser, launched.extensionId, {
      enabled: true,
      mode: "strict",
      disabledSites: [],
      modules: BASE_MODULES
    });
    const strictA = await readFingerprint(browser, primaryUrl);
    const strictB = await readFingerprint(browser, primaryUrl);
    const strictOtherSite = await readFingerprint(browser, alternateUrl);

    await applyConfig(browser, launched.extensionId, {
      enabled: true,
      mode: "balanced",
      disabledSites: ["127.0.0.1"],
      modules: BASE_MODULES
    });
    const excluded = await readFingerprint(browser, primaryUrl);

    console.log("Fixed-target assertions");
    check("hardwareConcurrency is 8", balanced.late.hardwareConcurrency === 8, `got ${balanced.late.hardwareConcurrency}`);
    check("deviceMemory is 8 GB when exposed", balanced.late.deviceMemory === undefined || balanced.late.deviceMemory === 8,
      `got ${balanced.late.deviceMemory}`);
    check("platform is Win32", balanced.late.platform === "Win32", `got ${balanced.late.platform}`);
    if (balanced.late.uaPlatform !== null) {
      check("UA-CH platform is Windows", balanced.late.uaPlatform === "Windows", `got ${balanced.late.uaPlatform}`);
      check("UA-CH toJSON platform is Windows", balanced.late.uaJSONPlatform === "Windows", `got ${balanced.late.uaJSONPlatform}`);
      check("legacy and UA-CH platform persona are coherent", balanced.late.platform === "Win32" && balanced.late.uaPlatform === "Windows");
    } else skip("UA-CH platform is Windows", "navigator.userAgentData unavailable");
    check("language profile is en-US/en", balanced.late.language === "en-US" && balanced.late.languages.join(",") === "en-US,en");
    check("screen is 1920 x 1080 x 24", balanced.late.screenWidth === 1920 && balanced.late.screenHeight === 1080 && balanced.late.colorDepth === 24,
      `got ${balanced.late.screenWidth}x${balanced.late.screenHeight}x${balanced.late.colorDepth}`);
    check("devicePixelRatio is 1", balanced.late.devicePixelRatio === 1, `got ${balanced.late.devicePixelRatio}`);
    check("July offset is EDT 240", balanced.late.timezoneOffsetJuly === 240, `got ${balanced.late.timezoneOffsetJuly}`);
    check("January offset is EST 300", balanced.late.timezoneOffsetJanuary === 300, `got ${balanced.late.timezoneOffsetJanuary}`);
    check("default Intl timezone is America/New_York", balanced.late.intlTimeZone === "America/New_York", `got ${balanced.late.intlTimeZone}`);
    check("explicit Europe/London remains explicit", balanced.late.intlExplicitLondon === "Europe/London", `got ${balanced.late.intlExplicitLondon}`);
    check("Date.toString uses Eastern daylight time", balanced.late.dateStringJuly.includes("Eastern Daylight Time"), balanced.late.dateStringJuly);
    check("WebGL debug vendor is suppressed", balanced.late.webglDebugVendor === null || balanced.late.webglDebugVendor === "unavailable",
      `got ${balanced.late.webglDebugVendor}`);
    check("WebGL debug renderer is suppressed", balanced.late.webglDebugRenderer === null || balanced.late.webglDebugRenderer === "unavailable",
      `got ${balanced.late.webglDebugRenderer}`);
    if (balanced.late.webglDebugRendererAdvertised !== null) {
      check("WEBGL_debug_renderer_info is absent from supported extensions", balanced.late.webglDebugRendererAdvertised === false);
    } else skip("WEBGL_debug_renderer_info is absent from supported extensions", "WebGL unavailable");
    if (balanced.late.webglDebugRenderer !== "unavailable") {
      check("synthetic WebGL extension is present", Boolean(balanced.late.webglSyntheticExtension),
        `got ${balanced.late.webglSyntheticExtension}`);
    } else skip("synthetic WebGL extension is present", "WebGL unavailable");

    console.log("\nInterference assertions");
    check("canvas differs on versus off", balanced.late.canvasHash !== off.late.canvasHash);
    if (balanced.late.webglHash !== null && off.late.webglHash !== null) {
      check("WebGL pixels differ on versus off", balanced.late.webglHash !== off.late.webglHash);
    } else skip("WebGL pixels differ on versus off", "WebGL unavailable");
    if (balanced.late.audioHash !== null && off.late.audioHash !== null) {
      check("audio data differs on versus off", balanced.late.audioHash !== off.late.audioHash);
    } else skip("audio data differs on versus off", "OfflineAudioContext unavailable");

    console.log("\nStability and privacy assertions");
    check("Balanced output is stable from the earliest page script", sameInterference(balanced.early, balanced.late));
    check("Strict output is stable from the earliest page script", sameInterference(strictA.early, strictA.late));
    check("Strict output is stable across reloads", sameInterference(strictA.late, strictB.late));
    if (strictA.late.webglSyntheticExtension || strictB.late.webglSyntheticExtension) {
      check("synthetic WebGL extension is stable across reloads", strictA.late.webglSyntheticExtension === strictB.late.webglSyntheticExtension);
    }
    check("different first parties receive different interference", !sameInterference(strictA.late, strictOtherSite.late));
    check("no raw session-seed message is exposed", !balanced.late.traceveilMessages.some((message) => message?.source === "traceveil-session-seed"));
    check("per-site exclusion restores unprotected canvas", excluded.late.canvasHash === off.late.canvasHash);
    check("per-site exclusion restores native navigator.platform", excluded.late.platform === off.late.platform, `${excluded.late.platform} vs ${off.late.platform}`);
    if (off.late.uaPlatform !== null) {
      check("per-site exclusion restores native UA-CH platform", excluded.late.uaPlatform === off.late.uaPlatform, `${excluded.late.uaPlatform} vs ${off.late.uaPlatform}`);
      check("per-site exclusion restores native UA-CH toJSON platform", excluded.late.uaJSONPlatform === off.late.uaJSONPlatform, `${excluded.late.uaJSONPlatform} vs ${off.late.uaJSONPlatform}`);
    }
    if (off.late.webglHash !== null && excluded.late.webglHash !== null) {
      check("per-site exclusion restores unprotected WebGL", excluded.late.webglHash === off.late.webglHash);
    }
    if (off.late.audioHash !== null && excluded.late.audioHash !== null) {
      check("per-site exclusion restores unprotected audio", excluded.late.audioHash === off.late.audioHash);
    }

    console.log(`\n${PASS.length} passed, ${FAIL.length} failed, ${SKIP.length} skipped.`);
    if (FAIL.length) process.exitCode = 1;
  } finally {
    if (browser) await browser.close().catch(() => {});
    await new Promise((resolve) => server.close(resolve));
    fs.rmSync(path.join(os.tmpdir(), "traceveil-unused"), { recursive: true, force: true });
  }
}

main().catch((error) => {
  console.error(`Harness failed:\n${error.stack || error.message}`);
  process.exit(1);
});
