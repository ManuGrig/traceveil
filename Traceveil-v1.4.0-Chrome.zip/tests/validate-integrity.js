#!/usr/bin/env node
"use strict";

const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const manifestPath = path.join(root, "SOURCE_MANIFEST.sha256");
if (!fs.existsSync(manifestPath)) throw new Error("Missing SOURCE_MANIFEST.sha256");

const expected = new Map();
for (const rawLine of fs.readFileSync(manifestPath, "utf8").split(/\r?\n/)) {
  const line = rawLine.trimEnd();
  if (!line) continue;
  const match = line.match(/^([a-f0-9]{64})  (.+)$/);
  if (!match) throw new Error(`Malformed source-manifest line: ${rawLine}`);
  if (expected.has(match[2])) throw new Error(`Duplicate source-manifest entry: ${match[2]}`);
  expected.set(match[2], match[1]);
}

function walk(directory, prefix = "") {
  const output = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name === ".git") continue;
    const relative = prefix ? path.posix.join(prefix, entry.name) : entry.name;
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) output.push(...walk(full, relative));
    else if (relative !== "SOURCE_MANIFEST.sha256") output.push(relative);
  }
  return output.sort();
}

const files = walk(root);
for (const file of files) {
  if (!expected.has(file)) throw new Error(`SOURCE_MANIFEST.sha256 is missing ${file}`);
  const digest = crypto.createHash("sha256").update(fs.readFileSync(path.join(root, file))).digest("hex");
  if (digest !== expected.get(file)) throw new Error(`SHA-256 mismatch for ${file}`);
}
for (const file of expected.keys()) {
  if (!files.includes(file)) throw new Error(`SOURCE_MANIFEST.sha256 references missing file ${file}`);
}

console.log(`Traceveil integrity validation passed (${files.length} files)`);
