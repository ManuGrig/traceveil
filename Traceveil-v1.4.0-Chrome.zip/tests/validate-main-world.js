#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const defaultsSource = fs.readFileSync(path.join(root, "defaults.js"), "utf8");
const strictSource = fs.readFileSync(path.join(root, "profile-strict.js"), "utf8");
const disableCanvasSource = fs.readFileSync(path.join(root, "profile-disable-canvas.js"), "utf8");
const disableWebGLSource = fs.readFileSync(path.join(root, "profile-disable-webgl.js"), "utf8");
const disableWebGPUSource = fs.readFileSync(path.join(root, "profile-disable-webgpu.js"), "utf8");
const disableHardwareSource = fs.readFileSync(path.join(root, "profile-disable-hardware.js"), "utf8");
const mainSource = fs.readFileSync(path.join(root, "main-world.js"), "utf8");

if (/traceveil-session-seed|get-session-seed/.test(mainSource)) {
  throw new Error("Main-world code must not accept a page-visible session seed");
}
if (/getRandomValues\s*\(/.test(mainSource)) {
  throw new Error("Fingerprint output must not reseed on every navigation");
}
if (/replaceGetter\(Navigator\.prototype,\s*["']gpu["']/.test(mainSource)) {
  throw new Error("v1.4 must preserve WebGPU capability rather than hiding navigator.gpu");
}

const prelude = `
  globalThis.window = globalThis;
  globalThis.top = globalThis;
  globalThis.location = {
    hostname: "example.test",
    origin: "https://example.test",
    href: "https://example.test/",
    ancestorOrigins: []
  };
  globalThis.addEventListener = () => {};
  globalThis.removeEventListener = () => {};

  class NavigatorUAData {
    get brands() { return [{ brand: "Chromium", version: "151" }]; }
    get mobile() { return false; }
    get platform() { return "Linux"; }
    toJSON() { return { brands: this.brands, mobile: this.mobile, platform: "Linux" }; }
    async getHighEntropyValues(hints) {
      const result = { brands: this.brands, mobile: this.mobile, platform: "Linux" };
      for (const hint of Array.isArray(hints) ? hints : []) {
        if (hint === "architecture") result.architecture = "x86";
        if (hint === "bitness") result.bitness = "64";
        if (hint === "model") result.model = "Native Model";
        if (hint === "platformVersion") result.platformVersion = "6.8.0";
        if (hint === "wow64") result.wow64 = false;
        if (hint === "uaFullVersion") result.uaFullVersion = "151.0.1234.56";
        if (hint === "fullVersionList") result.fullVersionList = [{ brand: "Chromium", version: "151.0.1234.56" }];
      }
      return result;
    }
  }
  globalThis.NavigatorUAData = NavigatorUAData;

  class Navigator {}
  Object.defineProperties(Navigator.prototype, {
    hardwareConcurrency: { configurable: true, get() { return 24; } },
    deviceMemory: { configurable: true, get() { return 32; } },
    platform: { configurable: true, get() { return "Linux x86_64"; } },
    language: { configurable: true, get() { return "fr-CA"; } },
    languages: { configurable: true, get() { return ["fr-CA", "fr"]; } },
    userAgentData: { configurable: true, get() { return new NavigatorUAData(); } },
    gpu: { configurable: true, get() { return { requestAdapter() {} }; } }
  });
  globalThis.Navigator = Navigator;
  globalThis.navigator = new Navigator();

  class Screen {}
  for (const [key, value] of Object.entries({
    width: 2560, height: 1440, availWidth: 2560, availHeight: 1400,
    availTop: 0, availLeft: 0, colorDepth: 30, pixelDepth: 30
  })) {
    Object.defineProperty(Screen.prototype, key, { configurable: true, get() { return value; } });
  }
  globalThis.Screen = Screen;
  globalThis.screen = new Screen();

  class ScreenOrientation {}
  Object.defineProperties(ScreenOrientation.prototype, {
    angle: { configurable: true, get() { return 90; } },
    type: { configurable: true, get() { return "portrait-primary"; } }
  });
  globalThis.ScreenOrientation = ScreenOrientation;

  class Window {}
  globalThis.Window = Window;
  Object.defineProperty(globalThis, "devicePixelRatio", {
    configurable: true,
    get() { return 2; }
  });

  class CanvasRenderingContext2D {
    constructor(canvas) { this.canvas = canvas; }
    drawImage(source) { this.canvas._pixels = new Uint8ClampedArray(source._pixels); }
    getImageData() { return { data: new Uint8ClampedArray(this.canvas._pixels) }; }
    putImageData(image) { this.canvas._pixels = new Uint8ClampedArray(image.data); }
  }
  Object.defineProperties(CanvasRenderingContext2D.prototype.getImageData, {
    apply: { configurable: true, value() { throw new Error("poisoned getImageData.apply"); } },
    call: { configurable: true, value() { throw new Error("poisoned getImageData.call"); } }
  });
  globalThis.CanvasRenderingContext2D = CanvasRenderingContext2D;

  class HTMLCanvasElement {
    constructor() {
      this.width = 2;
      this.height = 1;
      this._pixels = new Uint8ClampedArray([10, 20, 30, 255, 40, 50, 60, 255]);
      this._context = new CanvasRenderingContext2D(this);
    }
    getContext(kind) { return kind === "2d" ? this._context : null; }
    toDataURL() { return Array.from(this._pixels).join(","); }
    toBlob(callback) { if (callback) callback({ pixels: Array.from(this._pixels) }); }
  }
  globalThis.HTMLCanvasElement = HTMLCanvasElement;
  globalThis.document = {
    createElement(name) { return name === "canvas" ? new HTMLCanvasElement() : {}; }
  };

  class WebGLRenderingContext {
    getSupportedExtensions() {
      return ["EXT_native_alpha", "WEBGL_debug_renderer_info", "WEBGL_debug_shaders", "EXT_native_beta"];
    }
    getExtension(name) {
      const normalized = String(name).toLowerCase();
      if (normalized === "webgl_debug_renderer_info") {
        return { UNMASKED_VENDOR_WEBGL: 0x9245, UNMASKED_RENDERER_WEBGL: 0x9246 };
      }
      if (normalized === "webgl_debug_shaders") return { getTranslatedShaderSource() {} };
      if (normalized === "ext_native_alpha" || normalized === "ext_native_beta") return {};
      return null;
    }
    getParameter(parameter) {
      if (parameter === 0x9245) return "Native Vendor";
      if (parameter === 0x9246) return "Native Renderer 9000";
      return 4096;
    }
    readPixels(_x, _y, width, height, _format, _type, pixels) {
      for (let i = 0; i < pixels.length; i += 1) pixels[i] = (i + width + height) & 255;
    }
  }
  class WebGL2RenderingContext extends WebGLRenderingContext {}
  globalThis.WebGLRenderingContext = WebGLRenderingContext;
  globalThis.WebGL2RenderingContext = WebGL2RenderingContext;

  const nativeAdapterInfo = Object.freeze({
    vendor: "0x10de",
    architecture: "ada",
    device: "0x2f50",
    description: "NVIDIA RTX Test",
    subgroupMaxSize: 32
  });
  class GPUAdapter {
    get info() { return nativeAdapterInfo; }
    requestAdapterInfo() { return Promise.resolve(nativeAdapterInfo); }
  }
  globalThis.GPUAdapter = GPUAdapter;

  class AudioBuffer {
    constructor() { this._data = new Float32Array([0.1, 0.2, 0.3, 0.4]); }
    getChannelData() { return this._data; }
    copyFromChannel(destination) { destination.set(this._data.subarray(0, destination.length)); }
  }
  globalThis.AudioBuffer = AudioBuffer;
`;

const buildContext = ({ strict = false, canvas = true, webgl = true, webgpu = true, hardware = true, host = "example.test" } = {}) => {
  const context = vm.createContext({ console });
  vm.runInContext(prelude, context, { filename: "test-prelude.js" });
  vm.runInContext(`location.hostname = ${JSON.stringify(host)}; location.origin = ${JSON.stringify(`https://${host}`)}; location.href = ${JSON.stringify(`https://${host}/`)};`, context);
  vm.runInContext(defaultsSource, context, { filename: "defaults.js" });
  if (strict) vm.runInContext(strictSource, context, { filename: "profile-strict.js" });
  if (!canvas) vm.runInContext(disableCanvasSource, context, { filename: "profile-disable-canvas.js" });
  if (!webgl) vm.runInContext(disableWebGLSource, context, { filename: "profile-disable-webgl.js" });
  if (!webgpu) vm.runInContext(disableWebGPUSource, context, { filename: "profile-disable-webgpu.js" });
  if (!hardware) vm.runInContext(disableHardwareSource, context, { filename: "profile-disable-hardware.js" });
  vm.runInContext(mainSource, context, { filename: "main-world.js" });
  return context;
};

const read = (context) => vm.runInContext(`(() => {
  const july = new Date(Date.UTC(2026, 6, 10, 12, 0, 0));
  const january = new Date(Date.UTC(2026, 0, 10, 12, 0, 0));
  const canvas = new HTMLCanvasElement();
  const gl = new WebGLRenderingContext();
  const beforeDebugVendor = gl.getParameter(0x9245);
  const debug = gl.getExtension("WEBGL_debug_renderer_info");
  const extensions = gl.getSupportedExtensions();
  const synthetic = extensions.find((name) => /^(?:EXT|WEBGL)_(?:buffer_residency|command_budget|context_priority|frame_pacing|image_residency|mesh_budget|pipeline_cache_hint|pipeline_residency|render_budget|resource_priority|shader_cache_hint|shader_residency|surface_priority|texture_budget|texture_residency|tile_residency|buffer_budget|context_priority_hint|frame_pacing_hint|render_budget|resource_priority_hint|shader_cache_hint|surface_priority_hint)$/.test(name)) || null;
  const fakeA = synthetic ? gl.getExtension(synthetic) : null;
  const fakeB = synthetic ? gl.getExtension(synthetic) : null;
  const pixels = new Uint8Array(8);
  gl.readPixels(0, 0, 2, 1, 0, 0, pixels);
  const adapter = new GPUAdapter();
  const adapterInfo = adapter.info;
  return {
    hardware: new Navigator().hardwareConcurrency,
    memory: new Navigator().deviceMemory,
    platform: new Navigator().platform,
    uaPlatform: new Navigator().userAgentData.platform,
    uaJSONPlatform: new Navigator().userAgentData.toJSON().platform,
    gpuExposed: Boolean(new Navigator().gpu),
    screen: [new Screen().width, new Screen().height],
    dpr: window.devicePixelRatio,
    timezone: new Intl.DateTimeFormat().resolvedOptions().timeZone,
    explicitLondon: new Intl.DateTimeFormat("en-US", { timeZone: "Europe/London" }).resolvedOptions().timeZone,
    julyOffset: july.getTimezoneOffset(),
    januaryOffset: january.getTimezoneOffset(),
    julyString: july.toString(),
    localeDefault: july.toLocaleString("en-US"),
    localeLondon: july.toLocaleString("en-US", { timeZone: "Europe/London" }),
    canvas: canvas.toDataURL(),
    canvasPixels: Array.from(canvas.getContext("2d").getImageData(0, 0, 2, 1).data),
    webglBeforeDebugVendor: beforeDebugVendor,
    webglVendor: debug ? gl.getParameter(debug.UNMASKED_VENDOR_WEBGL) : null,
    webglRenderer: debug ? gl.getParameter(debug.UNMASKED_RENDERER_WEBGL) : null,
    webglExtensions: extensions,
    syntheticExtension: synthetic,
    syntheticStableObject: fakeA !== null && fakeA === fakeB,
    debugRendererInfoHidden: debug === null,
    debugRendererInfoAdvertised: extensions.some((name) => String(name).toLowerCase() === "webgl_debug_renderer_info"),
    debugShadersHidden: gl.getExtension("WEBGL_debug_shaders") === null,
    webglPixels: Array.from(pixels),
    adapterVendor: adapterInfo.vendor,
    adapterArchitecture: adapterInfo.architecture,
    adapterDevice: adapterInfo.device,
    adapterDescription: adapterInfo.description,
    adapterSubgroupMaxSize: adapterInfo.subgroupMaxSize,
    adapterPrototypePreserved: Object.getPrototypeOf(adapterInfo) === Object.getPrototypeOf((new GPUAdapter()).info)
  };
})()`, context);

const balanced = read(buildContext());
if (balanced.hardware !== 8 || balanced.memory !== 8 || balanced.platform !== "Win32") {
  throw new Error("Hardware normalization failed");
}
if (balanced.uaPlatform !== "Windows" || balanced.uaJSONPlatform !== "Windows") {
  throw new Error(`UA-CH low-entropy platform coherence failed: ${balanced.uaPlatform} / ${balanced.uaJSONPlatform}`);
}
const hardwareOff = read(buildContext({ hardware: false }));
if (hardwareOff.platform !== "Linux x86_64" || hardwareOff.uaPlatform !== "Linux" || hardwareOff.uaJSONPlatform !== "Linux") {
  throw new Error(`Disabling hardware protection did not restore native platform surfaces: ${hardwareOff.platform} / ${hardwareOff.uaPlatform} / ${hardwareOff.uaJSONPlatform}`);
}
if (!balanced.gpuExposed) throw new Error("WebGPU capability was hidden instead of preserved");
if (balanced.screen[0] !== 1920 || balanced.screen[1] !== 1080 || balanced.dpr !== 1) {
  throw new Error("Screen or DPR normalization failed");
}
if (balanced.timezone !== "America/New_York") throw new Error(`Unexpected default timezone ${balanced.timezone}`);
if (balanced.explicitLondon !== "Europe/London") throw new Error("Explicit timezone requests must remain explicit");
if (balanced.julyOffset !== 240 || balanced.januaryOffset !== 300) {
  throw new Error(`DST offsets failed: July=${balanced.julyOffset}, January=${balanced.januaryOffset}`);
}
if (!balanced.julyString.includes("Eastern Daylight Time")) {
  throw new Error(`Date.toString timezone mismatch: ${balanced.julyString}`);
}
if (balanced.localeDefault === balanced.localeLondon) {
  throw new Error("Default and explicitly requested locale timezones unexpectedly match");
}

const unprotectedCanvas = read(buildContext({ canvas: false })).canvas;
if (balanced.canvas === unprotectedCanvas) throw new Error("Canvas protection did not change output");
if (!Array.isArray(balanced.canvasPixels) || balanced.canvasPixels.length !== 8) {
  throw new Error("Canvas getImageData invocation hardening failed");
}

if (balanced.webglBeforeDebugVendor !== null) {
  throw new Error(`Hard-coded WebGL debug enum leaked identity: ${balanced.webglBeforeDebugVendor}`);
}
if (!balanced.debugRendererInfoHidden) {
  throw new Error("WEBGL_debug_renderer_info was not suppressed");
}
if (balanced.debugRendererInfoAdvertised) {
  throw new Error("WEBGL_debug_renderer_info is hidden by getExtension() but still advertised by getSupportedExtensions()");
}
if (balanced.webglVendor !== null || balanced.webglRenderer !== null) {
  throw new Error(`WebGL renderer identity should be unavailable: ${balanced.webglVendor} / ${balanced.webglRenderer}`);
}
if (!balanced.syntheticExtension || !balanced.webglExtensions.includes(balanced.syntheticExtension)) {
  throw new Error("Synthetic WebGL extension was not inserted");
}
if (!balanced.syntheticStableObject) throw new Error("Synthetic getExtension object is not stable per context");
if (!balanced.debugShadersHidden) throw new Error("WEBGL_debug_shaders legacy protection regressed");

const webglOff = read(buildContext({ webgl: false }));
if (webglOff.webglVendor !== "Native Vendor" || webglOff.webglRenderer !== "Native Renderer 9000") {
  throw new Error("Disabling WebGL protection does not restore native renderer identity");
}
if (webglOff.debugRendererInfoHidden || !webglOff.debugRendererInfoAdvertised) {
  throw new Error("Disabling WebGL protection does not restore native WEBGL_debug_renderer_info semantics");
}
if (webglOff.syntheticExtension !== null) throw new Error("Synthetic extension remains visible when WebGL protection is disabled");

if (balanced.adapterVendor !== "" || balanced.adapterArchitecture !== "" || balanced.adapterDevice !== "" || balanced.adapterDescription !== "") {
  throw new Error("WebGPU adapter identity scrub failed");
}
if (balanced.adapterSubgroupMaxSize !== 32) throw new Error("WebGPU non-sensitive adapter fields were not preserved");
const webgpuOff = read(buildContext({ webgpu: false }));
if (webgpuOff.adapterVendor !== "0x10de" || webgpuOff.adapterDescription !== "NVIDIA RTX Test") {
  throw new Error("Disabling WebGPU protection does not restore native adapter info");
}

const strictA = read(buildContext({ strict: true }));
const strictB = read(buildContext({ strict: true }));
if (strictA.canvas !== strictB.canvas) throw new Error("Strict Canvas output is not stable across reload-equivalent contexts");
if (strictA.syntheticExtension !== strictB.syntheticExtension) throw new Error("Synthetic GPU extension is not stable for a first party");
const strictOtherSite = read(buildContext({ strict: true, host: "other.test" }));
if (strictA.canvas === strictOtherSite.canvas) throw new Error("First-party seeds do not separate Canvas output");
if (strictA.syntheticExtension === strictOtherSite.syntheticExtension && strictA.canvas === strictOtherSite.canvas) {
  throw new Error("First-party GPU farbling did not separate sites");
}

(async () => {
  const context = buildContext();
  const asyncInfo = await vm.runInContext(`(async () => {
    const info = await (new GPUAdapter()).requestAdapterInfo();
    return { vendor: info.vendor, architecture: info.architecture, device: info.device, description: info.description, subgroupMaxSize: info.subgroupMaxSize };
  })()`, context);
  if (asyncInfo.vendor !== "" || asyncInfo.architecture !== "" || asyncInfo.device !== "" || asyncInfo.description !== "") {
    throw new Error("WebGPU requestAdapterInfo async scrub failed");
  }
  if (asyncInfo.subgroupMaxSize !== 32) throw new Error("WebGPU async non-sensitive fields were not preserved");

  const strictContext = buildContext({ strict: true });
  const strictUA = await vm.runInContext(`(async () => {
    const data = new Navigator().userAgentData;
    const high = await data.getHighEntropyValues(["architecture", "bitness", "model", "platformVersion", "wow64", "uaFullVersion", "fullVersionList"]);
    return {
      platform: data.platform,
      jsonPlatform: data.toJSON().platform,
      architecture: high.architecture,
      bitness: high.bitness,
      model: high.model,
      platformVersion: high.platformVersion,
      wow64: high.wow64,
      uaFullVersion: high.uaFullVersion,
      fullVersion: high.fullVersionList?.[0]?.version
    };
  })()`, strictContext);
  if (strictUA.platform !== "Windows" || strictUA.jsonPlatform !== "Windows") {
    throw new Error(`Strict UA-CH platform coherence failed: ${strictUA.platform} / ${strictUA.jsonPlatform}`);
  }
  if (strictUA.architecture !== "x86" || strictUA.bitness !== "64" || strictUA.model !== "" || strictUA.platformVersion !== "10.0.0" || strictUA.wow64 !== false) {
    throw new Error(`Strict UA-CH high-entropy normalization failed: ${JSON.stringify(strictUA)}`);
  }
  if (strictUA.uaFullVersion !== "151.0.0.0" || strictUA.fullVersion !== "151.0.0.0") {
    throw new Error(`Strict UA version normalization failed: ${strictUA.uaFullVersion} / ${strictUA.fullVersion}`);
  }

  console.log("Traceveil main-world validation passed");
})().catch((error) => {
  console.error(error.stack || error.message);
  process.exitCode = 1;
});
