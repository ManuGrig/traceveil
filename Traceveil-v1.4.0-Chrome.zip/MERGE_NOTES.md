# Traceveil v1.4 Merge Notes

Traceveil v1.4.0 uses the uploaded v1.3.2 source package as the authoritative base. The stable release promotes the measured RC.1 protection behavior unchanged: all v1.3.2 modules remain present, while the v1.4 GPU and UA-CH coherence improvements are retained.

## Alpha.6 coherence fix

The Hardware module now normalizes the modern low-entropy UA-CH platform surface (`navigator.userAgentData.platform`) and its `toJSON()` representation to `Windows` whenever the existing Windows persona is active. This closes a direct JavaScript-level contradiction with `navigator.platform = "Win32"` on macOS/Linux hosts. Strict `platformVersion = "10.0.0"` remains unchanged. Network request headers and worker-only surfaces remain outside this extension-layer fix.

## Retained unchanged in architecture

- v1.3.2 service-worker synchronization model.
- Persistent MAIN-world `document_start` registration.
- Isolated iframe activation bridge with activation-only messaging.
- Balanced / Strict profiles.
- All module-level enable/disable profile scripts.
- Local tracker seed, DNR tracker blocking, URL-parameter removal, and Chrome privacy settings.
- Per-site exclusions.
- Deterministic first-party/mode seed with no page-visible session secret or per-install identifier.
- Canvas/OffscreenCanvas, audio, hardware, screen/DPR, language, timezone, Client Hints, battery, and font-probing defenses.

## Replaced in v1.4

### WebGL renderer identity

v1.3.2 suppressed `WEBGL_debug_renderer_info`. Alpha.5/alpha.6 changed that behavior to generic `WebKit` / `WebKit WebGL` values because we hypothesized that an unavailable debug renderer would itself be anomalous. Cover Your Tracks population measurements falsified that hypothesis: the generic pair was far rarer in the tested population than the unavailable/`None` result.

v1.4 therefore uses suppression and makes it coherent across both discovery paths: `getExtension("WEBGL_debug_renderer_info")` returns `null`, and `getSupportedExtensions()` no longer advertises that extension. Hard-coded unmasked enum probes are also suppressed. Synthetic-extension farbling, WebGL pixel interference, and WebGPU adapter scrubbing remain unchanged.

### WebGL extension surface

v1.4 adds one coherent deterministic synthetic extension per first party/protection mode. `getSupportedExtensions()` and `getExtension()` agree on the synthetic value. The selection derives from the existing Traceveil first-party seed rather than a new install/session secret.

### WebGPU

v1.3.2 hid `navigator.gpu` when the module was enabled. v1.4 preserves WebGPU capability and instead scrubs adapter identity fields where Chrome exposes an interceptable API. This improves compatibility and follows the "preserve capability, remove identity" design principle.

## Explicitly not adopted

- Per-navigation random GPU values.
- Seed import/export.
- A browser-global session seed exposed to page JavaScript.
- Randomizing arbitrary WebGL numeric capabilities that can be tested against real behavior.
- Claiming Blink-level equivalence to Brave from a Chrome extension.
