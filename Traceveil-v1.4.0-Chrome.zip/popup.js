"use strict";

const MODULE_GROUPS = Object.freeze({
  fingerprintModules: [
    { key: "canvas", icon: "CV", label: "Canvas output", detail: "First-party stable pixel perturbation" },
    { key: "webgl", icon: "GL", label: "WebGL output and GPU", detail: "Pixel interference + GPU identity scrub + extension farbling", badge: "NEW" },
    { key: "webgpu", icon: "WG", label: "WebGPU adapter", detail: "Preserve capability; scrub adapter identity where exposed", badge: "NEW" },
    { key: "audio", icon: "AU", label: "Audio output", detail: "Stable first-party audio interference" },
    { key: "hardware", icon: "HW", label: "CPU, memory and platform", detail: "Normalize high-entropy hardware values" },
    { key: "screen", icon: "SC", label: "Screen geometry", detail: "1920 × 1080 × 24 profile with DPR 1" },
    { key: "language", icon: "LN", label: "Language", detail: "Normalize JavaScript and request language signals" },
    { key: "timezone", icon: "TZ", label: "Timezone", detail: "DST-correct America/New_York consistency" },
    { key: "clientHints", icon: "CH", label: "High-entropy Client Hints", detail: "Reduce architecture/model/version hints", strictOnly: true },
    { key: "fonts", icon: "FT", label: "Experimental font probing", detail: "Reduce uncommon-font measurement probes", strictOnly: true },
    { key: "battery", icon: "BT", label: "Battery state", detail: "Normalize battery API output", strictOnly: true }
  ],
  networkModules: [
    { key: "webRTC", icon: "IP", label: "WebRTC local-IP protection", detail: "Disable non-proxied UDP exposure" },
    { key: "trackerBlocking", icon: "TR", label: "Known third-party trackers", detail: "Block bundled tracker domains and hyperlink auditing" },
    { key: "trackingParams", icon: "URL", label: "Tracking URL parameters", detail: "Remove common attribution parameters on navigation" },
    { key: "privacySandbox", icon: "PS", label: "Privacy Sandbox tracking APIs", detail: "Disable Topics, Protected Audience and related APIs" },
    { key: "thirdPartyCookies", icon: "CK", label: "Block third-party cookies", detail: "Chrome privacy setting", strictOnly: true },
    { key: "networkPrediction", icon: "NP", label: "Disable network prediction", detail: "Reduce predictive/preconnect behavior", strictOnly: true }
  ]
});

const GPU_FAKE_EXTENSIONS = Object.freeze([
  "EXT_buffer_residency", "EXT_command_budget", "EXT_context_priority", "EXT_frame_pacing",
  "EXT_image_residency", "EXT_mesh_budget", "EXT_pipeline_cache_hint", "EXT_pipeline_residency",
  "EXT_render_budget", "EXT_resource_priority", "EXT_shader_cache_hint", "EXT_shader_residency",
  "EXT_surface_priority", "EXT_texture_budget", "EXT_texture_residency", "EXT_tile_residency",
  "WEBGL_buffer_budget", "WEBGL_context_priority_hint", "WEBGL_frame_pacing_hint",
  "WEBGL_pipeline_cache_hint", "WEBGL_render_budget", "WEBGL_resource_priority_hint",
  "WEBGL_shader_cache_hint", "WEBGL_surface_priority_hint", "WEBGL_texture_budget", "WEBGL_tile_residency"
]);

const $ = (id) => document.getElementById(id);
const els = {
  enabled: $("enabled"), siteEnabled: $("siteEnabled"), siteEnabledMirror: $("siteEnabledMirror"),
  host: $("host"), sitePanelHost: $("sitePanelHost"), heroCard: $("heroCard"), statusDot: $("statusDot"),
  statusLabel: $("statusLabel"), summary: $("summary"), balancedMode: $("balancedMode"), strictMode: $("strictMode"),
  modeHelp: $("modeHelp"), fingerprintModules: $("fingerprintModules"), networkModules: $("networkModules"),
  webglBadge: $("webglBadge"), webglDetail: $("webglDetail"), farbleBadge: $("farbleBadge"),
  farbleDetail: $("farbleDetail"), trackerOverview: $("trackerOverview"), trackerBadge: $("trackerBadge"),
  trackerState: $("trackerState"), syntheticCard: $("syntheticCard"), syntheticExtension: $("syntheticExtension"),
  standardizeWindow: $("standardizeWindow"), testButton: $("testButton"), aboutTestButton: $("aboutTestButton"),
  addSiteForm: $("addSiteForm"), addSiteInput: $("addSiteInput"), siteFormMessage: $("siteFormMessage"),
  excludedSites: $("excludedSites"), excludedCount: $("excludedCount")
};

const state = {
  tab: null,
  host: "",
  config: null,
  moduleInputs: new Map(),
  tracker: null
};

function setBadge(element, label, kind) {
  element.textContent = label;
  element.className = `state-badge ${kind}`;
}

function isWebUrl(url) {
  return /^https?:\/\//i.test(url || "");
}

function displayHost(url) {
  try {
    const parsed = new URL(url);
    return isWebUrl(url) ? (parsed.hostname || parsed.origin) : `${parsed.protocol.replace(":", "")} page`;
  } catch {
    return "Chrome page";
  }
}

function normalizeSites(sites) {
  return [...new Set((Array.isArray(sites) ? sites : [])
    .map((site) => String(site).trim().toLowerCase())
    .filter((site) => /^(?:[a-z0-9-]+\.)*[a-z0-9-]+$/i.test(site)))]
    .sort();
}

function hostIsDisabled(host, sites) {
  const normalizedHost = String(host || "").toLowerCase();
  return normalizeSites(sites).some((site) => normalizedHost === site || normalizedHost.endsWith(`.${site}`));
}

function normalizeDomainInput(raw) {
  let value = String(raw || "").trim().toLowerCase();
  if (!value) return null;
  try {
    const candidate = value.includes("://") ? value : `https://${value}`;
    const parsed = new URL(candidate);
    value = parsed.hostname.toLowerCase();
  } catch {
    value = value.replace(/^\*\./, "").replace(/^\.+|\.+$/g, "");
  }
  value = value.replace(/^\*\./, "").replace(/^\.+|\.+$/g, "");
  if (!/^(?:[a-z0-9-]+\.)*[a-z0-9-]+$/i.test(value)) return null;
  if (value.split(".").some((label) => !label || label.length > 63 || label.startsWith("-") || label.endsWith("-"))) return null;
  return value;
}

function renderTabs() {
  document.querySelectorAll(".nav-pill").forEach((button) => {
    button.addEventListener("click", () => {
      document.querySelectorAll(".nav-pill").forEach((item) => item.classList.toggle("active", item === button));
      document.querySelectorAll(".panel").forEach((panel) => panel.classList.toggle("active", panel.id === button.dataset.panel));
    });
  });
}

function makeModuleRow(definition) {
  const row = document.createElement("label");
  row.className = `module-row${definition.strictOnly ? " strict-only" : ""}`;
  row.dataset.moduleRow = definition.key;

  const icon = document.createElement("span");
  icon.className = "row-icon";
  icon.textContent = definition.icon;

  const copy = document.createElement("span");
  copy.className = "row-copy";
  const title = document.createElement("strong");
  title.append(document.createTextNode(definition.label));
  if (definition.strictOnly) {
    const tag = document.createElement("span");
    tag.className = "strict-tag";
    tag.textContent = "STRICT";
    title.append(tag);
  }
  if (definition.badge) {
    const tag = document.createElement("span");
    tag.className = "new-tag";
    tag.textContent = definition.badge;
    title.append(tag);
  }
  const detail = document.createElement("span");
  detail.textContent = definition.detail;
  copy.append(title, detail);

  const toggle = document.createElement("span");
  toggle.className = "inline-switch module-toggle";
  const input = document.createElement("input");
  input.type = "checkbox";
  input.dataset.module = definition.key;
  input.setAttribute("aria-label", definition.label);
  const track = document.createElement("span");
  track.className = "switch-track small";
  const thumb = document.createElement("span");
  thumb.className = "switch-thumb";
  track.append(thumb);
  toggle.append(input, track);
  row.append(icon, copy, toggle);
  state.moduleInputs.set(definition.key, input);

  input.addEventListener("change", async () => {
    state.config.modules[definition.key] = input.checked;
    await chrome.storage.local.set({ modules: state.config.modules });
    await syncAndReload();
  });
  return row;
}

function renderModuleRows() {
  for (const definition of MODULE_GROUPS.fingerprintModules) els.fingerprintModules.append(makeModuleRow(definition));
  for (const definition of MODULE_GROUPS.networkModules) els.networkModules.append(makeModuleRow(definition));
}

function syncControlsFromConfig() {
  const config = state.config;
  els.enabled.checked = Boolean(config.enabled);
  const siteProtected = Boolean(state.host && !hostIsDisabled(state.host, config.disabledSites));
  els.siteEnabled.checked = siteProtected;
  els.siteEnabledMirror.checked = siteProtected;
  els.siteEnabled.disabled = !state.host;
  els.siteEnabledMirror.disabled = !state.host;
  els.balancedMode.classList.toggle("active", config.mode !== "strict");
  els.strictMode.classList.toggle("active", config.mode === "strict");
  els.modeHelp.textContent = config.mode === "strict" ? "Stronger normalization; compatibility may decrease" : "Stable first-party protection with compatibility focus";
  els.standardizeWindow.classList.toggle("hidden", config.mode !== "strict");

  for (const [key, input] of state.moduleInputs) input.checked = Boolean(config.modules[key]);
  document.querySelectorAll(".strict-only").forEach((row) => row.classList.toggle("dormant", config.mode !== "strict"));

  const active = Boolean(config.enabled && siteProtected);
  els.heroCard.classList.toggle("off", !active);
  els.statusDot.classList.toggle("off", !active);
  els.statusLabel.textContent = active ? "Protection active" : "Protection off";
  els.summary.textContent = active
    ? `${config.mode === "strict" ? "Strict" : "Balanced"} protection is active on this site.`
    : config.enabled
      ? "This site is excluded from page-level protection; browser-global privacy settings may remain active."
      : "Traceveil is globally disabled; this site sees native browser values.";

  renderExcludedSites();
}

async function syncConfigOnly() {
  return chrome.runtime.sendMessage({ type: "sync-config" }).catch((error) => ({ ok: false, error: error.message }));
}

async function syncAndReload() {
  syncControlsFromConfig();
  const response = await syncConfigOnly();
  if (response?.ok && state.tab?.id && isWebUrl(state.tab.url)) {
    await chrome.tabs.reload(state.tab.id);
  }
}

async function standardizeWindow() {
  els.standardizeWindow.disabled = true;
  els.standardizeWindow.textContent = "Standardizing…";
  try {
    const currentWindow = await chrome.windows.getCurrent();
    const response = await chrome.runtime.sendMessage({
      type: "standardize-window",
      windowId: currentWindow.id,
      tabId: state.tab?.id
    }).catch((error) => ({ ok: false, error: error.message }));
    if (!response?.ok) throw new Error(response?.error || "Window update failed");
  } catch {
    els.standardizeWindow.textContent = "Resize failed — try manually";
    els.standardizeWindow.disabled = false;
  }
}

async function setMode(mode) {
  if (!state.config || !["balanced", "strict"].includes(mode) || state.config.mode === mode) return;
  state.config.mode = mode;
  await chrome.storage.local.set({ mode });
  syncControlsFromConfig();
  if (mode === "strict") await standardizeWindow();
  else await syncAndReload();
}

async function setGlobalEnabled(enabled) {
  state.config.enabled = Boolean(enabled);
  await chrome.storage.local.set({ enabled: state.config.enabled });
  await syncAndReload();
}

async function setCurrentSiteProtected(protectedState) {
  if (!state.host) return;
  const sites = new Set(normalizeSites(state.config.disabledSites));
  if (protectedState) {
    for (const site of [...sites]) {
      if (state.host === site || state.host.endsWith(`.${site}`)) sites.delete(site);
    }
  } else {
    sites.add(state.host);
  }
  state.config.disabledSites = [...sites].sort();
  await chrome.storage.local.set({ disabledSites: state.config.disabledSites });
  await syncAndReload();
}

function renderExcludedSites() {
  if (!state.config) return;
  const sites = normalizeSites(state.config.disabledSites);
  els.excludedCount.textContent = String(sites.length);
  els.excludedSites.textContent = "";
  if (!sites.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "No excluded domains.";
    els.excludedSites.append(empty);
    return;
  }
  for (const site of sites) {
    const row = document.createElement("div");
    row.className = "excluded-row";
    const code = document.createElement("code");
    code.textContent = site;
    const remove = document.createElement("button");
    remove.type = "button";
    remove.textContent = "Remove";
    remove.addEventListener("click", async () => {
      state.config.disabledSites = normalizeSites(state.config.disabledSites).filter((item) => item !== site);
      await chrome.storage.local.set({ disabledSites: state.config.disabledSites });
      syncControlsFromConfig();
      await syncConfigOnly();
      if (state.host && (state.host === site || state.host.endsWith(`.${site}`)) && state.tab?.id && isWebUrl(state.tab.url)) {
        await chrome.tabs.reload(state.tab.id);
      }
    });
    row.append(code, remove);
    els.excludedSites.append(row);
  }
}

async function loadTrackerState() {
  const tracker = await chrome.runtime.sendMessage({ type: "get-tracker-state" })
    .catch((error) => ({ ok: false, error: error.message }));
  state.tracker = tracker;
  if (!tracker?.ok) {
    els.trackerOverview.textContent = "Local tracker seed unavailable";
    els.trackerState.textContent = "Local tracker seed unavailable";
    setBadge(els.trackerBadge, "N/A", "pending");
    return;
  }
  const activeCount = Number(tracker.activeCount ?? 0);
  const totalCount = Number(tracker.count ?? activeCount);
  const date = tracker.updatedAt ? new Date(tracker.updatedAt).toLocaleDateString() : null;
  if (tracker.active) {
    els.trackerOverview.textContent = `${activeCount.toLocaleString()} local tracker domains active`;
    setBadge(els.trackerBadge, "ACTIVE", "good");
  } else {
    els.trackerOverview.textContent = `${totalCount.toLocaleString()} domains available; blocking is off`;
    setBadge(els.trackerBadge, "OFF", "off");
  }
  els.trackerState.textContent = tracker.active
    ? `${activeCount.toLocaleString()} domains active${date ? ` · seed ${date}` : ""}`
    : `${totalCount.toLocaleString()} domains available${date ? ` · seed ${date}` : ""}`;
}

async function probeCurrentTab() {
  const siteProtected = Boolean(state.config?.enabled && state.config.modules.webgl && state.host && !hostIsDisabled(state.host, state.config.disabledSites));
  if (!siteProtected) {
    setBadge(els.webglBadge, "OFF", "off");
    setBadge(els.farbleBadge, "OFF", "off");
    els.webglDetail.textContent = state.config?.enabled ? "WebGL protection is disabled for this site or module." : "Traceveil is globally disabled.";
    els.farbleDetail.textContent = "Synthetic extension is not active.";
    els.syntheticCard.classList.add("hidden");
    return;
  }
  if (!state.tab?.id || !isWebUrl(state.tab.url)) {
    setBadge(els.webglBadge, "N/A", "pending");
    setBadge(els.farbleBadge, "N/A", "pending");
    els.webglDetail.textContent = "Open a regular website to verify WebGL protection.";
    els.farbleDetail.textContent = "Chrome pages cannot be probed.";
    return;
  }

  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: state.tab.id },
      world: "MAIN",
      func: (fakePool) => {
        try {
          const canvas = document.createElement("canvas");
          const gl = canvas.getContext("webgl2") || canvas.getContext("webgl");
          if (!gl) return { webgl: false };
          const debug = gl.getExtension("WEBGL_debug_renderer_info");
          const vendor = debug ? gl.getParameter(debug.UNMASKED_VENDOR_WEBGL) : null;
          const renderer = debug ? gl.getParameter(debug.UNMASKED_RENDERER_WEBGL) : null;
          const extensions = gl.getSupportedExtensions() || [];
          const debugRendererAdvertised = extensions.some((name) => String(name).toLowerCase() === "webgl_debug_renderer_info");
          const syntheticExtension = extensions.find((name) => fakePool.includes(name)) || null;
          return {
            webgl: true,
            vendor,
            renderer,
            rendererProtected: debug === null && !debugRendererAdvertised,
            syntheticExtension,
            webgpuAvailable: typeof navigator.gpu !== "undefined"
          };
        } catch (error) {
          return { webgl: false, error: String(error?.message || error) };
        }
      },
      args: [GPU_FAKE_EXTENSIONS]
    });
    const probe = results?.[0]?.result;
    if (!probe?.webgl) {
      setBadge(els.webglBadge, "N/A", "pending");
      setBadge(els.farbleBadge, "N/A", "pending");
      els.webglDetail.textContent = probe?.error || "WebGL is unavailable on this page.";
      els.farbleDetail.textContent = "No WebGL extension surface to inspect.";
      return;
    }
    if (probe.rendererProtected) {
      setBadge(els.webglBadge, "ACTIVE", "good");
      els.webglDetail.textContent = "GPU debug renderer identity is suppressed.";
    } else if (probe.vendor === null && probe.renderer === null) {
      setBadge(els.webglBadge, "LIMITED", "warn");
      els.webglDetail.textContent = "Renderer values are unavailable, but the debug extension surface is still advertised.";
    } else {
      setBadge(els.webglBadge, "NATIVE", "off");
      els.webglDetail.textContent = "Native GPU renderer identity is still exposed on this loaded page.";
    }

    if (probe.syntheticExtension) {
      setBadge(els.farbleBadge, "ACTIVE", "good");
      els.farbleDetail.textContent = "Coherent site-scoped synthetic extension present.";
      els.syntheticExtension.textContent = probe.syntheticExtension;
      els.syntheticCard.classList.remove("hidden");
    } else {
      setBadge(els.farbleBadge, "NOT SEEN", "off");
      els.farbleDetail.textContent = "Synthetic extension was not detected on this loaded page.";
      els.syntheticCard.classList.add("hidden");
    }
  } catch {
    setBadge(els.webglBadge, "N/A", "pending");
    setBadge(els.farbleBadge, "N/A", "pending");
    els.webglDetail.textContent = "Chrome did not allow a live probe on this page.";
    els.farbleDetail.textContent = "Use BrowserLeaks for external verification.";
  }
}

async function openBrowserLeaks() {
  await chrome.tabs.create({ url: "https://browserleaks.com/webgl" });
}

async function initialize() {
  renderTabs();
  renderModuleRows();

  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  state.tab = tabs?.[0] || null;
  state.host = "";
  try { state.host = new URL(state.tab?.url).hostname.toLowerCase(); } catch {}
  const hostLabel = displayHost(state.tab?.url);
  els.host.textContent = hostLabel;
  els.sitePanelHost.textContent = hostLabel;

  const stored = await chrome.storage.local.get(TRACEVEIL_DEFAULTS);
  state.config = {
    ...TRACEVEIL_DEFAULTS,
    ...stored,
    mode: stored.mode === "aggressive" ? "strict" : (stored.mode || TRACEVEIL_DEFAULTS.mode),
    disabledSites: normalizeSites(stored.disabledSites),
    modules: { ...TRACEVEIL_DEFAULTS.modules, ...(stored.modules || {}) }
  };

  syncControlsFromConfig();
  await Promise.all([loadTrackerState(), probeCurrentTab()]);

  els.enabled.addEventListener("change", () => setGlobalEnabled(els.enabled.checked));
  els.siteEnabled.addEventListener("change", () => setCurrentSiteProtected(els.siteEnabled.checked));
  els.siteEnabledMirror.addEventListener("change", () => setCurrentSiteProtected(els.siteEnabledMirror.checked));
  els.balancedMode.addEventListener("click", () => setMode("balanced"));
  els.strictMode.addEventListener("click", () => setMode("strict"));
  els.standardizeWindow.addEventListener("click", standardizeWindow);
  els.testButton.addEventListener("click", openBrowserLeaks);
  els.aboutTestButton.addEventListener("click", openBrowserLeaks);

  els.addSiteForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const domain = normalizeDomainInput(els.addSiteInput.value);
    els.siteFormMessage.classList.remove("error");
    if (!domain) {
      els.siteFormMessage.textContent = "Enter a valid hostname such as example.com.";
      els.siteFormMessage.classList.add("error");
      return;
    }
    const sites = new Set(normalizeSites(state.config.disabledSites));
    sites.add(domain);
    state.config.disabledSites = [...sites].sort();
    await chrome.storage.local.set({ disabledSites: state.config.disabledSites });
    els.addSiteInput.value = "";
    els.siteFormMessage.textContent = `${domain} excluded.`;
    syncControlsFromConfig();
    await syncConfigOnly();
    if (state.host && (state.host === domain || state.host.endsWith(`.${domain}`)) && state.tab?.id && isWebUrl(state.tab.url)) {
      await chrome.tabs.reload(state.tab.id);
    }
  });
}

initialize().catch((error) => {
  console.warn("Traceveil popup initialization failed:", error);
});
