# Third-Party Notices

The Chrome extension itself bundles no third-party JavaScript libraries and does not fetch third-party tracker datasets or executable code.

The optional development verification workflow uses Puppeteer 25.3.0, installed separately with `npm install`. Puppeteer and its transitive packages are not bundled into the extension and retain their respective licenses; see `package-lock.json` and the installed packages for details.

The tracker-domain seed in `rules/tracker-domains.json` is distributed as part of this project under 0BSD.

The Traceveil logo and derived icon files are project artwork. Before redistributing them under 0BSD, ensure that you hold the necessary rights to do so.
