globalThis.TRACEVEIL_DEFAULTS = Object.freeze({
  enabled: true,
  mode: "balanced",
  disabledSites: Object.freeze([]),
  modules: Object.freeze({
    canvas: true,
    webgl: true,
    webgpu: true,
    audio: true,
    hardware: true,
    screen: true,
    language: true,
    timezone: true,
    clientHints: true,
    fonts: false,
    battery: true,
    webRTC: true,
    trackerBlocking: true,
    trackingParams: true,
    privacySandbox: true,
    thirdPartyCookies: true,
    networkPrediction: true
  })
});
