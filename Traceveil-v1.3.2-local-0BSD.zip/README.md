<p align="center">
  <img src="assets/traceveil-logo.png" alt="Traceveil logo" width="180">
</p>

# Traceveil

## Reduce what your browser reveals

> **v1.3.2:** hardens Canvas and other protected browser-API wrappers against pages that shadow or modify JavaScript invocation helpers. It retains the v1.3.1 privacy architecture: stable first-party Strict-mode interference without a browser-session identifier, DST-correct timezone consistency, matching device-pixel-ratio normalization, local tracker controls, and reproducible validation tools.

Traceveil is a privacy extension for Chrome that reduces browser fingerprinting and limits common tracking signals. It combines fingerprint normalization, controlled interference, lightweight tracker filtering, and browser privacy controls in one transparent, configurable extension.

Instead of pretending to make your browser invisible, Traceveil makes selected browser signals less reliable and less identifying while preserving enough functionality for ordinary websites to work. Protection is applied before page scripts run and operates across frames, helping prevent trackers from collecting the original high-entropy values first.

## Install locally

1. Download or clone this repository.
2. Open `chrome://extensions`.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the project folder containing `manifest.json`.
6. Reload any already-open pages.

## Fingerprint protection

Modern tracking does not depend entirely on cookies. Websites can combine dozens of browser and hardware characteristics to recognize a device, including screen geometry, graphics hardware, processor count, memory, language, timezone, canvas rendering, WebGL output, WebGPU support, and audio processing.

Traceveil reduces the usefulness of these signals by presenting a more standardized browser profile and interfering with high-entropy rendering outputs.

Protection includes:

- Canvas output perturbation
- WebGL output protection and GPU identity suppression
- WebGPU adapter protection
- Audio fingerprint interference
- CPU, memory, and platform normalization
- Screen geometry, color-depth, and device-pixel-ratio normalization
- Language normalization and DST-correct timezone consistency across `Intl`, offsets, and common `Date` strings
- High-entropy User-Agent Client Hint reduction
- Battery normalization in stricter protection modes
- Optional experimental font-probing defenses
- Basic resistance to scripts inspecting modified JavaScript functions

Traceveil does not randomly invent a completely different identity for every browser API. Its protections are designed to keep related values internally consistent and avoid obvious contradictions that could make the browser even more unusual.

## Balanced and Strict modes

**Balanced mode** provides stable first-party fingerprint protection with a focus on compatibility. Canvas, WebGL, and audio interference remain consistent within each first-party domain, reducing cross-site correlation without causing values to fluctuate during normal page use.

**Strict mode** adds stronger defenses for more privacy-sensitive browsing. It uses denser rendering and audio perturbation while keeping each first party stable across reloads. The seed is derived only from the protection mode and first-party hostname: Traceveil does not send a raw browser-session secret into the webpage or introduce a per-install identifier. Strict mode also reduces additional Client Hints, normalizes battery information, blocks third-party cookies, disables network prediction, and can standardize the browser window.

Strict mode may affect graphics applications, editors, authentication systems, video services, or websites that depend heavily on device detection. Individual sites can be excluded when compatibility is more important.

## Tracker controls

Traceveil includes lightweight local tracker controls for common advertising, analytics, attribution, session-replay, and fingerprinting infrastructure.

This local-only build does not download or bundle restricted third-party tracker datasets. Instead, it uses a small bundled local seed list and browser-level request controls to reduce common tracking channels while keeping the project simple to audit and suitable for unrestricted open-source publication.

Tracker controls include:

- Basic third-party tracker-domain blocking
- Third-party ping and hyperlink-auditing protection
- Removal of common tracking parameters such as `utm_*`, `gclid`, `fbclid`, and `msclkid`
- WebRTC local-IP protection
- Privacy Sandbox API controls where Chrome exposes them
- Strict-mode third-party cookie blocking
- Per-site exceptions for applicable request rules

Traceveil is not intended to replace a full ad blocker. Its primary purpose is fingerprint resistance and signal reduction. The tracker controls are a secondary layer designed to reduce common tracking paths without adding remote telemetry, account systems, or proprietary update services.

## Clear, local controls

Traceveil gives you direct control over each protection category. You can enable or disable protection globally, exclude a specific website, switch between Balanced and Strict modes, and independently control fingerprint and network modules.

No account is required. There is no cloud dashboard, behavioral profile, advertising system, or remote configuration service. Settings are stored locally in the browser.

Per-site exceptions disable protection for matching page origins and applicable request rules. Browser-global privacy settings remain active, and some embedded third-party frames may remain protected.

## Measurable protection

In comparative Cover Your Tracks testing, Traceveil substantially reduced the identifying value of several high-entropy browser signals. Canvas, WebGL, and audio results were reported as randomized by first-party domain, while exposed screen, timezone, language, processor, memory, and GPU characteristics became significantly more common than the original hardware profile.

A browser may still be reported as unique because fingerprint tests combine many attributes and are limited by the size of their datasets. The important measurement is not only the headline result, but how much identifying information each protected signal continues to reveal.

Traceveil is designed to reduce linkability. It does not promise anonymity.

## Automated verification

The package includes three dependency-free validations and one optional real-browser harness:

```bash
npm test
```

This checks package consistency, service-worker registration and rule generation, install-time hardening, tracker-status accuracy, stable first-party interference, screen/DPR normalization, and timezone behavior.

For end-to-end verification in Chrome:

```bash
npm install
npm run verify
```

The browser harness pins Puppeteer 25.3.0 and tests exact normalized targets, Canvas/WebGL/audio changes, earliest-script versus later stability, Strict-mode reload stability, first-party separation, per-site exclusions, and the absence of a page-visible session-seed channel. Chrome extension loading can be unavailable in restricted containers; the harness reports that limitation rather than treating an unexecuted run as a pass.

## Honest limitations

Traceveil improves tracking resistance, but it does not make a browser anonymous.

It does not:

- Hide or change your public IP address
- Replace a VPN or anonymity network
- Control TLS, JA3, JA4, HTTP/2, HTTP/3, QUIC, DNS, or network-stack fingerprints
- Create isolated browser profiles
- Prevent every form of first-party tracking
- Guarantee that modified APIs are undetectable
- Defeat every current or future fingerprinting technique
- Fully reconcile the Windows-oriented JavaScript platform persona with a non-Windows browser's network User-Agent and low-entropy Client Hints

For stronger identity separation, use dedicated Chrome profiles or separate browser installations alongside appropriate network-level privacy tools.

## Privacy without pretending to be invisible

Traceveil is designed to reduce linkability, suppress unusually revealing hardware characteristics, and make browser fingerprints less reliable while remaining honest about the limits of a Chrome extension.

It does not make you disappear.

It gives websites less dependable information to work with.

## License

Traceveil is released under the [Zero-Clause BSD license](LICENSE). See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for the bundled-data and artwork notice.

## Direct comparison

Test performed with [Cover Your Tracks](https://coveryourtracks.eff.org/). Results are specific to the tested browser, hardware, date, and comparison population.

| Metric | Without extension | With extension | Result |
|---|---:|---:|---:|
| HTTP Accept / language header | 11.17 bits / 1 in 2,307.87 | 1.49 bits / 1 in 2.81 | ~821× more common |
| Timezone name | America/Toronto, 6.23 bits / 1 in 75.3 | America/New_York, 3.60 bits / 1 in 12.1 | ~6.2× more common |
| Screen | 2752×1152×32, 11.80 bits / 1 in 3,554 | 1920×1080×24, 3.43 bits / 1 in 10.79 | ~329× more common |
| Canvas | fixed hash, 10.56 bits / 1 in 1,512 | first-party-specific controlled interference | ~768× more common |
| WebGL hash | fixed hash, 14.12 bits / 1 in 17,770 | first-party-specific controlled interference | ~7,969× more common |
| WebGL renderer | RTX 5070, 12.95 bits / 1 in 7,898 | None, 7.13 bits / 1 in 139.77 | ~56× more common |
| Audio | fixed value, 2.92 bits / 1 in 7.59 | first-party-specific controlled interference | ~2.8× more common |
| CPU cores | 24, 7.09 bits / 1 in 136.49 | 8, 2.08 bits / 1 in 4.24 | ~32× more common |
| Device memory | 32 GB, 3.88 bits / 1 in 14.76 | 8 GB, 2.61 bits / 1 in 6.12 | ~2.4× more common |
