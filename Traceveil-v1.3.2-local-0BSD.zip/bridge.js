if (window.top !== window) {
  const firstPartyOrigin = location.ancestorOrigins?.length
    ? location.ancestorOrigins[location.ancestorOrigins.length - 1]
    : location.origin;
  let host = location.hostname;
  try { host = new URL(firstPartyOrigin).hostname; } catch {}

  chrome.runtime.sendMessage({ type: "get-frame-state", host }, (state) => {
    if (chrome.runtime.lastError || state?.enabled !== true) return;
    // This one-way bridge can activate protection but cannot be used by page
    // scripts to disable it. No settings or site lists are exposed.
    window.postMessage({ source: "traceveil-frame-state", enabled: true }, "*");
  });
}
