# v1.3.1 Merge Notes

This version uses Traceveil v1.2.1 as the authoritative base and selectively incorporates or improves the useful work found in the reviewed v1.3.0 iteration.

## Adopted

- DST-correct `America/New_York` normalization across the default `Intl.DateTimeFormat`, timezone offsets, common `Date` strings, and `toLocale*()` calls.
- Preservation of explicitly requested timezones such as `Europe/London`.
- `devicePixelRatio` normalization aligned with the 1920 × 1080 screen profile, corrected to patch Chromium's configurable getter on the `window` object.
- A real-Chrome Puppeteer verification concept, expanded to test early-page behavior, WebGL pixels, correctly sampled audio, site separation, exclusions, and prohibited seed leakage.
- Reproducible test dependency metadata and documentation.

## Rejected or replaced

- The raw browser-session seed relay through `window.postMessage`. It exposed a common cross-site value to webpages and allowed page scripts to race or spoof the message.
- The fallback-seed-to-session-seed transition during a live document. It could change fingerprint output after an early page probe.
- Page-visible iframe messages that could turn protection off. v1.3.1 retains activation-only behavior.
- Removal of `match_origin_as_fallback` from the isolated bridge.
- Regression from `Promise.allSettled()` to `Promise.all()` for optional Chrome privacy settings.
- Removal of legacy dynamic-script cleanup.
- Additional `tabs` and `windows` manifest permissions, which are not required by this build.

## Replacement design

Strict mode now uses a deterministic first-party-and-mode seed and stronger perturbation density. This makes output stable from the first page script and across reloads without exposing a browser-global secret, creating a per-install identifier, or changing output midway through a document.
