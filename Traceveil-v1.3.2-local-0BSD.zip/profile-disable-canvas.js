if (!globalThis.TRACEVEIL_DEFAULTS) throw new Error("Traceveil defaults unavailable");
globalThis.TRACEVEIL_DEFAULTS = Object.freeze({
  ...globalThis.TRACEVEIL_DEFAULTS,
  modules: Object.freeze({ ...globalThis.TRACEVEIL_DEFAULTS.modules, canvas: false })
});
