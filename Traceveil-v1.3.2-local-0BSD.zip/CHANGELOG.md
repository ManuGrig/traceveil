# Changelog

## 1.3.2

### Fixed

- Fixed a Chrome error in the Canvas `getImageData()` wrapper caused when a page shadows a captured method's `.apply()` or `.call()` property.
- Protected native browser APIs are now invoked through an early captured `Reflect.apply` reference rather than mutable page-visible invocation properties.
- Canvas and OffscreenCanvas pixel perturbation now falls back to the unmodified native result if only Traceveil's post-processing step fails. Native browser exceptions are still preserved.

### Tests

- Added a regression test that deliberately poisons `getImageData.apply` and `getImageData.call`; Canvas protection must continue to work without throwing.
- Confirmed the fix in real headless Chromium with Canvas `getImageData()` and `toDataURL()` while both invocation properties were poisoned.
- Replaced environment-specific package-lock registry URLs with public npm registry URLs so `npm install` remains portable.

## 1.3.1

### Added

- Consistent `devicePixelRatio = 1` normalization alongside the 1920 × 1080 × 24 screen profile.
- DST-correct `America/New_York` behavior across default `Intl.DateTimeFormat`, `Date.getTimezoneOffset()`, `Date.toString()`, `Date.toDateString()`, `Date.toTimeString()`, and the `toLocale*()` methods.
- A dependency-free main-world validation harness.
- An expanded real-Chrome Puppeteer harness covering fixed targets, Canvas/WebGL/audio interference, early-script stability, reload stability, first-party separation, exclusions, and seed-channel leakage.
- A pinned test dependency and package lock for reproducible browser verification.

### Changed

- Strict-mode interference is now stable by first party and protection mode. It no longer draws fresh random entropy on every navigation.
- Tracker status now reports zero active domains when tracker blocking or Traceveil itself is disabled, while still showing how many bundled domains are available.
- Documentation now distinguishes dependency-free validation from optional end-to-end Chrome verification.

### Security

- Rejected the v1.3.0 raw `chrome.storage.session` seed relay through `window.postMessage`. No browser-global seed or per-install identifier is exposed to webpages.
- Retained the hardened v1.2.1 install/startup synchronization and optional privacy-setting failure isolation.
- Retained one-way iframe activation: page-visible messages may activate protection but cannot turn it off.
- Retained `match_origin_as_fallback` for both the main-world registration and isolated bridge so related `about:`, `data:`, `blob:`, and `filesystem:` frames remain covered.
