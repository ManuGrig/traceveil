if (!globalThis.TRACEVEIL_DEFAULTS) {
  throw new Error("Traceveil: defaults.js must load before profile-strict.js");
}
globalThis.TRACEVEIL_DEFAULTS = Object.freeze({
  ...globalThis.TRACEVEIL_DEFAULTS,
  mode: "strict"
});
