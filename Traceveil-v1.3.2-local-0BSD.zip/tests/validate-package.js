const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");
const mustExist = (file) => {
  if (!fs.existsSync(path.join(root, file))) throw new Error(`Missing ${file}`);
};

const manifest = JSON.parse(read("manifest.json"));
if (manifest.manifest_version !== 3) throw new Error("Manifest V3 required");
if (manifest.name !== "Traceveil") throw new Error(`Unexpected extension name ${manifest.name}`);
if (manifest.version !== "1.3.2") throw new Error(`Unexpected manifest version ${manifest.version}`);
if (Number(manifest.minimum_chrome_version) < 119) throw new Error("Chrome 119+ is required for matchOriginAsFallback");
if (manifest.action?.default_title !== "Traceveil") throw new Error("Action title is not branded Traceveil");
if (manifest.permissions.includes("alarms")) throw new Error("alarms permission must not be present");
if (!manifest.permissions.includes("privacy")) throw new Error("privacy permission is required");
if (!manifest.permissions.includes("declarativeNetRequest")) throw new Error("declarativeNetRequest permission is required");
if (manifest.permissions.includes("tabs")) throw new Error("tabs permission is unnecessary with declared host access");
if (manifest.permissions.includes("windows")) throw new Error("windows is not a required manifest permission");

for (const size of [16, 32, 48, 128]) {
  const iconPath = manifest.icons[String(size)];
  mustExist(iconPath);
  const png = fs.readFileSync(path.join(root, iconPath));
  if (png.toString("ascii", 1, 4) !== "PNG") throw new Error(`${iconPath} is not a PNG`);
  const width = png.readUInt32BE(16);
  const height = png.readUInt32BE(20);
  if (width !== size || height !== size) throw new Error(`${iconPath} is ${width}x${height}, expected ${size}x${size}`);
}

mustExist("assets/traceveil-logo.png");
mustExist(manifest.background.service_worker);
for (const script of manifest.content_scripts.flatMap((entry) => entry.js)) mustExist(script);
for (const entry of manifest.content_scripts) {
  if (entry.run_at !== "document_start") throw new Error("Bridge must run at document_start");
  if (!entry.all_frames) throw new Error("Bridge must run in all frames");
  if (!entry.match_origin_as_fallback) throw new Error("Bridge must cover related about/data/blob frames");
}

const packageJson = JSON.parse(read("package.json"));
if (packageJson.name !== "traceveil") throw new Error("package.json name mismatch");
if (packageJson.version !== manifest.version) throw new Error("package.json version mismatch");
if (packageJson.license !== "0BSD") throw new Error("Expected 0BSD license metadata");
if (packageJson.private !== true) throw new Error("package.json should prevent accidental npm publication");
if (packageJson.devDependencies?.puppeteer !== "25.3.0") throw new Error("Puppeteer must be pinned to 25.3.0");
const packageLock = read("package-lock.json");
if (/applied-caas-gateway|internal\.api\.openai\.org/.test(packageLock)) {
  throw new Error("package-lock.json contains environment-specific registry URLs");
}
if (!packageJson.scripts?.test?.includes("validate-main-world.js")) throw new Error("Main-world validation is not part of npm test");

const popupHtml = read("popup.html");
if (!popupHtml.includes(`v${manifest.version}</footer>`)) throw new Error("Popup footer version mismatch");

const bridgeSource = read("bridge.js");
const serviceWorkerSource = read("service-worker.js");
const mainWorldSource = read("main-world.js");
if (/traceveil-session-seed|get-session-seed/.test(`${bridgeSource}
${serviceWorkerSource}
${mainWorldSource}`)) {
  throw new Error("A page-visible session-seed channel is forbidden");
}
if (/getRandomValues\s*\(/.test(mainWorldSource)) {
  throw new Error("Main-world fingerprint output must not reseed on every navigation");
}
if (/\.(?:apply|call)\s*\(/.test(mainWorldSource)) {
  throw new Error("Main-world native APIs must use the captured Reflect.apply invoker");
}
if (!mainWorldSource.includes("const nativeReflectApply = Reflect.apply")) {
  throw new Error("Captured Reflect.apply invocation hardening is missing");
}
if (!mainWorldSource.includes('replaceGetter(window, "devicePixelRatio", "screen", 1)')) {
  throw new Error("Screen profile must normalize devicePixelRatio");
}
if (!mainWorldSource.includes('const TARGET_TIMEZONE = "America/New_York"')) {
  throw new Error("Consistent timezone implementation is missing");
}

const forbidden = [
  /staticcdn/i,
  /trackerblocking\/v6/i,
  /tds\.json/i,
  /TRACKER_LIST_URL/,
  /refresh-tracker-list/i,
  /chrome\.alarms/,
  /IDENTITY_FIREWALL_DEFAULTS/,
  /identity-firewall-frame-state/
];
for (const file of fs.readdirSync(root, { recursive: true })) {
  const full = path.join(root, file);
  if (fs.statSync(full).isDirectory()) continue;
  if (file === path.join("tests", "validate-package.js")) continue;
  if (/\.(png|zip)$/i.test(file)) continue;
  const text = fs.readFileSync(full, "utf8");
  for (const pattern of forbidden) {
    if (pattern.test(text)) throw new Error(`Forbidden reference ${pattern} in ${file}`);
  }
}

const oldBrand = /Identity Firewall/;
for (const file of fs.readdirSync(root, { recursive: true })) {
  const full = path.join(root, file);
  if (fs.statSync(full).isDirectory() || /\.(png|zip)$/i.test(file)) continue;
  if (file === path.join("tests", "validate-package.js")) continue;
  const text = fs.readFileSync(full, "utf8");
  if (oldBrand.test(text)) throw new Error(`Old product name remains in ${file}`);
}

const seed = JSON.parse(read("rules/tracker-domains.json"));
if (seed.source !== "Traceveil local tracker seed") throw new Error("Tracker seed branding mismatch");
if (seed.license !== "0BSD") throw new Error("Tracker seed must be 0BSD-labeled");
const balanced = seed.balanced || [];
const strict = seed.strict || [];
const domains = [...balanced, ...strict];
if (balanced.length < 50 || strict.length < 50) throw new Error("Tracker seed unexpectedly small");
if (new Set(domains).size !== domains.length) throw new Error("Tracker seed contains duplicate domains");
for (const domain of domains) {
  if (!/^(?:[a-z0-9-]+\.)+[a-z0-9-]+$/.test(domain)) throw new Error(`Invalid domain ${domain}`);
}

for (const file of fs.readdirSync(root, { recursive: true }).filter((name) => name.endsWith(".js"))) {
  new vm.Script(read(file), { filename: file });
}

console.log("Traceveil package validation passed");
