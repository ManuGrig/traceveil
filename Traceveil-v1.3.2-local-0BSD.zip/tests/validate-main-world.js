#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const defaultsSource = fs.readFileSync(path.join(root, "defaults.js"), "utf8");
const strictSource = fs.readFileSync(path.join(root, "profile-strict.js"), "utf8");
const disableCanvasSource = fs.readFileSync(path.join(root, "profile-disable-canvas.js"), "utf8");
const mainSource = fs.readFileSync(path.join(root, "main-world.js"), "utf8");

if (/traceveil-session-seed|get-session-seed/.test(mainSource)) {
  throw new Error("Main-world code must not accept a page-visible session seed");
}
if (/getRandomValues\s*\(/.test(mainSource)) {
  throw new Error("Strict fingerprint output must not reseed on every navigation");
}

const prelude = `
  globalThis.window = globalThis;
  globalThis.top = globalThis;
  globalThis.location = {
    hostname: "example.test",
    origin: "https://example.test",
    ancestorOrigins: []
  };
  globalThis.addEventListener = () => {};
  globalThis.removeEventListener = () => {};

  class Navigator {}
  Object.defineProperties(Navigator.prototype, {
    hardwareConcurrency: { configurable: true, get() { return 24; } },
    deviceMemory: { configurable: true, get() { return 32; } },
    platform: { configurable: true, get() { return "Linux x86_64"; } },
    language: { configurable: true, get() { return "fr-CA"; } },
    languages: { configurable: true, get() { return ["fr-CA", "fr"]; } }
  });
  globalThis.Navigator = Navigator;
  globalThis.navigator = new Navigator();

  class Screen {}
  for (const [key, value] of Object.entries({
    width: 2560, height: 1440, availWidth: 2560, availHeight: 1400,
    availTop: 0, availLeft: 0, colorDepth: 30, pixelDepth: 30
  })) {
    Object.defineProperty(Screen.prototype, key, { configurable: true, get() { return value; } });
  }
  globalThis.Screen = Screen;
  globalThis.screen = new Screen();

  class ScreenOrientation {}
  Object.defineProperties(ScreenOrientation.prototype, {
    angle: { configurable: true, get() { return 90; } },
    type: { configurable: true, get() { return "portrait-primary"; } }
  });
  globalThis.ScreenOrientation = ScreenOrientation;

  class Window {}
  globalThis.Window = Window;
  Object.defineProperty(globalThis, "devicePixelRatio", {
    configurable: true,
    get() { return 2; }
  });

  class CanvasRenderingContext2D {
    constructor(canvas) { this.canvas = canvas; }
    drawImage(source) { this.canvas._pixels = new Uint8ClampedArray(source._pixels); }
    getImageData() { return { data: new Uint8ClampedArray(this.canvas._pixels) }; }
    putImageData(image) { this.canvas._pixels = new Uint8ClampedArray(image.data); }
  }
  // Simulate a hostile or instrumentation-heavy page that shadows the
  // familiar invocation helpers on a native-like API function. Traceveil
  // must invoke the captured method through Reflect.apply instead.
  Object.defineProperties(CanvasRenderingContext2D.prototype.getImageData, {
    apply: { configurable: true, value() { throw new Error("poisoned getImageData.apply"); } },
    call: { configurable: true, value() { throw new Error("poisoned getImageData.call"); } }
  });
  globalThis.CanvasRenderingContext2D = CanvasRenderingContext2D;

  class HTMLCanvasElement {
    constructor() {
      this.width = 2;
      this.height = 1;
      this._pixels = new Uint8ClampedArray([10, 20, 30, 255, 40, 50, 60, 255]);
      this._context = new CanvasRenderingContext2D(this);
    }
    getContext(kind) { return kind === "2d" ? this._context : null; }
    toDataURL() { return Array.from(this._pixels).join(","); }
    toBlob(callback) { if (callback) callback({ pixels: Array.from(this._pixels) }); }
  }
  globalThis.HTMLCanvasElement = HTMLCanvasElement;
  globalThis.document = {
    createElement(name) { return name === "canvas" ? new HTMLCanvasElement() : {}; }
  };

  class AudioBuffer {
    constructor() { this._data = new Float32Array([0.1, 0.2, 0.3, 0.4]); }
    getChannelData() { return this._data; }
    copyFromChannel(destination) { destination.set(this._data.subarray(0, destination.length)); }
  }
  globalThis.AudioBuffer = AudioBuffer;
`;

const buildContext = ({ strict = false, canvas = true, host = "example.test" } = {}) => {
  const context = vm.createContext({ console });
  vm.runInContext(prelude, context, { filename: "test-prelude.js" });
  vm.runInContext(`location.hostname = ${JSON.stringify(host)}; location.origin = ${JSON.stringify(`https://${host}`)};`, context);
  vm.runInContext(defaultsSource, context, { filename: "defaults.js" });
  if (strict) vm.runInContext(strictSource, context, { filename: "profile-strict.js" });
  if (!canvas) vm.runInContext(disableCanvasSource, context, { filename: "profile-disable-canvas.js" });
  vm.runInContext(mainSource, context, { filename: "main-world.js" });
  return context;
};

const read = (context) => vm.runInContext(`(() => {
  const july = new Date(Date.UTC(2026, 6, 10, 12, 0, 0));
  const january = new Date(Date.UTC(2026, 0, 10, 12, 0, 0));
  const canvas = new HTMLCanvasElement();
  return {
    hardware: new Navigator().hardwareConcurrency,
    memory: new Navigator().deviceMemory,
    platform: new Navigator().platform,
    screen: [new Screen().width, new Screen().height],
    dpr: window.devicePixelRatio,
    timezone: new Intl.DateTimeFormat().resolvedOptions().timeZone,
    explicitLondon: new Intl.DateTimeFormat("en-US", { timeZone: "Europe/London" }).resolvedOptions().timeZone,
    julyOffset: july.getTimezoneOffset(),
    januaryOffset: january.getTimezoneOffset(),
    julyString: july.toString(),
    localeDefault: july.toLocaleString("en-US"),
    localeLondon: july.toLocaleString("en-US", { timeZone: "Europe/London" }),
    canvas: canvas.toDataURL(),
    canvasPixels: Array.from(canvas.getContext("2d").getImageData(0, 0, 2, 1).data)
  };
})()`, context);

const balanced = read(buildContext());
if (balanced.hardware !== 8 || balanced.memory !== 8 || balanced.platform !== "Win32") {
  throw new Error("Hardware normalization failed");
}
if (balanced.screen[0] !== 1920 || balanced.screen[1] !== 1080 || balanced.dpr !== 1) {
  throw new Error("Screen or DPR normalization failed");
}
if (balanced.timezone !== "America/New_York") throw new Error(`Unexpected default timezone ${balanced.timezone}`);
if (balanced.explicitLondon !== "Europe/London") throw new Error("Explicit timezone requests must remain explicit");
if (balanced.julyOffset !== 240 || balanced.januaryOffset !== 300) {
  throw new Error(`DST offsets failed: July=${balanced.julyOffset}, January=${balanced.januaryOffset}`);
}
if (!balanced.julyString.includes("Eastern Daylight Time")) {
  throw new Error(`Date.toString timezone mismatch: ${balanced.julyString}`);
}
if (balanced.localeDefault === balanced.localeLondon) {
  throw new Error("Default and explicitly requested locale timezones unexpectedly match");
}

const unprotectedCanvas = read(buildContext({ canvas: false })).canvas;
if (balanced.canvas === unprotectedCanvas) throw new Error("Canvas protection did not change output");
if (!Array.isArray(balanced.canvasPixels) || balanced.canvasPixels.length !== 8) {
  throw new Error("Canvas getImageData invocation hardening failed");
}

const strictA = read(buildContext({ strict: true })).canvas;
const strictB = read(buildContext({ strict: true })).canvas;
if (strictA !== strictB) throw new Error("Strict output is not stable across reload-equivalent contexts");
const strictOtherSite = read(buildContext({ strict: true, host: "other.test" })).canvas;
if (strictA === strictOtherSite) throw new Error("First-party seeds do not separate sites");

console.log("Traceveil main-world validation passed");
